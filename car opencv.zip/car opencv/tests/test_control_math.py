"""Tests for NRL JARVIS Vision — Control Mathematics"""

import math
import pytest
from src.control_math import (
    clamp,
    compute_raw_steering,
    exponential_moving_average,
    time_aware_alpha,
    apply_deadband,
    differential_drive_mix,
    ramp_limit,
    echo_to_distance_m,
    distance_to_cm,
    obstacle_throttle_limit,
    stopping_distance,
    line_array_position,
    wrap_angle,
    heading_error,
    compute_two_hand_steering_angle,
    normalize_two_hand_steering,
)


class TestClamp:
    def test_within_range(self):
        assert clamp(0.5, 0.0, 1.0) == 0.5

    def test_at_minimum(self):
        assert clamp(0.0, 0.0, 1.0) == 0.0

    def test_at_maximum(self):
        assert clamp(1.0, 0.0, 1.0) == 1.0

    def test_below_minimum(self):
        assert clamp(-0.5, 0.0, 1.0) == 0.0

    def test_above_maximum(self):
        assert clamp(1.5, 0.0, 1.0) == 1.0

    def test_nan_raises(self):
        with pytest.raises(ValueError):
            clamp(float("nan"), 0.0, 1.0)

    def test_inf_raises(self):
        with pytest.raises(ValueError):
            clamp(float("inf"), 0.0, 1.0)

    def test_neg_inf_raises(self):
        with pytest.raises(ValueError):
            clamp(float("-inf"), 0.0, 1.0)


class TestComputeRawSteering:
    def test_center_gives_zero(self):
        assert compute_raw_steering(320.0, 640.0) == pytest.approx(0.0)

    def test_right_of_center(self):
        assert compute_raw_steering(400.0, 640.0) == pytest.approx(0.25)

    def test_left_of_center(self):
        assert compute_raw_steering(240.0, 640.0) == pytest.approx(-0.25)

    def test_full_right(self):
        assert compute_raw_steering(640.0, 640.0) == pytest.approx(1.0)

    def test_full_left(self):
        assert compute_raw_steering(0.0, 640.0) == pytest.approx(-1.0)

    def test_clamps_beyond_right(self):
        assert compute_raw_steering(800.0, 640.0) == pytest.approx(1.0)

    def test_clamps_beyond_left(self):
        assert compute_raw_steering(-100.0, 640.0) == pytest.approx(-1.0)

    def test_inversion(self):
        normal = compute_raw_steering(400.0, 640.0, invert=False)
        inverted = compute_raw_steering(400.0, 640.0, invert=True)
        assert inverted == pytest.approx(-normal)

    def test_custom_center(self):
        result = compute_raw_steering(300.0, 640.0, center_x=300.0)
        assert result == pytest.approx(0.0)

    def test_custom_range(self):
        result = compute_raw_steering(420.0, 640.0, center_x=320.0, steering_range=200.0)
        assert result == pytest.approx(0.5)

    def test_zero_width_raises(self):
        with pytest.raises(ValueError):
            compute_raw_steering(100.0, 0.0)

    def test_negative_width_raises(self):
        with pytest.raises(ValueError):
            compute_raw_steering(100.0, -640.0)

    def test_nan_x_raises(self):
        with pytest.raises(ValueError):
            compute_raw_steering(float("nan"), 640.0)

    def test_inf_x_raises(self):
        with pytest.raises(ValueError):
            compute_raw_steering(float("inf"), 640.0)

    def test_nan_width_raises(self):
        with pytest.raises(ValueError):
            compute_raw_steering(320.0, float("nan"))


class TestEMA:
    def test_full_weight_on_current(self):
        assert exponential_moving_average(1.0, 0.0, 1.0) == pytest.approx(1.0)

    def test_half_weight(self):
        assert exponential_moving_average(1.0, 0.0, 0.5) == pytest.approx(0.5)

    def test_quarter_weight(self):
        result = exponential_moving_average(1.0, 0.0, 0.25)
        assert result == pytest.approx(0.25)

    def test_convergence(self):
        val = 0.0
        for _ in range(100):
            val = exponential_moving_average(1.0, val, 0.25)
        assert val == pytest.approx(1.0, abs=0.01)

    def test_zero_alpha_raises(self):
        with pytest.raises(ValueError):
            exponential_moving_average(1.0, 0.0, 0.0)

    def test_negative_alpha_raises(self):
        with pytest.raises(ValueError):
            exponential_moving_average(1.0, 0.0, -0.1)

    def test_alpha_above_1_raises(self):
        with pytest.raises(ValueError):
            exponential_moving_average(1.0, 0.0, 1.5)

    def test_nan_input_raises(self):
        with pytest.raises(ValueError):
            exponential_moving_average(float("nan"), 0.0, 0.5)


class TestDeadband:
    def test_within_deadband_is_zero(self):
        assert apply_deadband(0.03, 0.05) == 0.0

    def test_at_deadband_is_zero(self):
        assert apply_deadband(0.049, 0.05) == 0.0

    def test_above_deadband_passes(self):
        assert apply_deadband(0.1, 0.05) == 0.1

    def test_negative_within_deadband(self):
        assert apply_deadband(-0.03, 0.05) == 0.0

    def test_negative_above_deadband(self):
        assert apply_deadband(-0.1, 0.05) == -0.1

    def test_zero_deadband(self):
        assert apply_deadband(0.001, 0.0) == 0.001

    def test_invalid_deadband_raises(self):
        with pytest.raises(ValueError):
            apply_deadband(0.5, 1.0)
        with pytest.raises(ValueError):
            apply_deadband(0.5, -0.1)


class TestDifferentialDrive:
    def test_zero_zero(self):
        result = differential_drive_mix(0.0, 0.0)
        assert result.left == pytest.approx(0.0)
        assert result.right == pytest.approx(0.0)

    def test_pure_forward(self):
        result = differential_drive_mix(0.6, 0.0)
        assert result.left == pytest.approx(0.6)
        assert result.right == pytest.approx(0.6)

    def test_pure_reverse(self):
        result = differential_drive_mix(-0.6, 0.0)
        assert result.left == pytest.approx(-0.6)
        assert result.right == pytest.approx(-0.6)

    def test_forward_right(self):
        result = differential_drive_mix(0.6, 0.2)
        assert result.left == pytest.approx(0.4)
        assert result.right == pytest.approx(0.8)

    def test_forward_left(self):
        result = differential_drive_mix(0.6, -0.2)
        assert result.left == pytest.approx(0.8)
        assert result.right == pytest.approx(0.4)

    def test_normalization(self):
        result = differential_drive_mix(1.0, 1.0)
        assert result.left == pytest.approx(0.0)
        assert result.right == pytest.approx(1.0)
        assert abs(result.left) <= 1.0
        assert abs(result.right) <= 1.0

    def test_preserves_ratio(self):
        result = differential_drive_mix(0.8, 0.6)
        assert result.left == pytest.approx(0.2 / 1.4)
        assert result.right == pytest.approx(1.4 / 1.4)

    def test_outputs_always_bounded(self):
        for v in [-1.0, -0.5, 0.0, 0.5, 1.0]:
            for s in [-1.0, -0.5, 0.0, 0.5, 1.0]:
                result = differential_drive_mix(v, s)
                assert -1.0 <= result.left <= 1.0
                assert -1.0 <= result.right <= 1.0

    def test_nan_throttle_raises(self):
        with pytest.raises(ValueError):
            differential_drive_mix(float("nan"), 0.0)

    def test_inf_steering_raises(self):
        with pytest.raises(ValueError):
            differential_drive_mix(0.0, float("inf"))


class TestRampLimit:
    def test_within_rate(self):
        result = ramp_limit(0.5, 0.0, 0.1, 10.0, 10.0)
        assert result == pytest.approx(0.5)

    def test_limited_accel(self):
        result = ramp_limit(1.0, 0.0, 0.1, 2.0, 2.0)
        assert result == pytest.approx(0.2)

    def test_limited_decel(self):
        result = ramp_limit(0.0, 1.0, 0.1, 2.0, 3.0)
        assert result == pytest.approx(0.7)

    def test_output_clamped(self):
        result = ramp_limit(2.0, 0.9, 0.5, 10.0, 10.0)
        assert result <= 1.0

    def test_negative_dt_raises(self):
        with pytest.raises(ValueError):
            ramp_limit(0.5, 0.0, -0.1, 2.0, 2.0)

    def test_zero_rate_raises(self):
        with pytest.raises(ValueError):
            ramp_limit(0.5, 0.0, 0.1, 0.0, 2.0)


class TestObstacleDistance:
    def test_echo_to_distance(self):
        result = echo_to_distance_m(0.0015, 343.0)
        assert result == pytest.approx(0.25725)

    def test_zero_echo(self):
        assert echo_to_distance_m(0.0) == pytest.approx(0.0)

    def test_negative_echo_raises(self):
        with pytest.raises(ValueError):
            echo_to_distance_m(-0.001)

    def test_nan_echo_raises(self):
        with pytest.raises(ValueError):
            echo_to_distance_m(float("nan"))

    def test_distance_to_cm(self):
        assert distance_to_cm(0.25725) == pytest.approx(25.725)

    def test_throttle_limit_below_min(self):
        result = obstacle_throttle_limit(10.0, 15.0, 50.0, 0.3)
        assert result == pytest.approx(0.0)

    def test_throttle_limit_above_safe(self):
        result = obstacle_throttle_limit(60.0, 15.0, 50.0, 0.3)
        assert result == pytest.approx(0.3)

    def test_throttle_limit_between(self):
        result = obstacle_throttle_limit(32.5, 15.0, 50.0, 0.3)
        assert result == pytest.approx(0.15)

    def test_negative_distance_raises(self):
        with pytest.raises(ValueError):
            obstacle_throttle_limit(-5.0, 15.0, 50.0, 0.3)


class TestStoppingDistance:
    def test_basic(self):
        result = stopping_distance(2.0, 0.1, 5.0)
        assert result == pytest.approx(0.6)

    def test_zero_speed(self):
        result = stopping_distance(0.0, 0.1, 5.0)
        assert result == pytest.approx(0.0)

    def test_with_margin(self):
        result = stopping_distance(2.0, 0.1, 5.0, 0.5)
        assert result == pytest.approx(1.1)

    def test_zero_decel_raises(self):
        with pytest.raises(ValueError):
            stopping_distance(2.0, 0.1, 0.0)

    def test_negative_decel_raises(self):
        with pytest.raises(ValueError):
            stopping_distance(2.0, 0.1, -5.0)

    def test_negative_speed_raises(self):
        with pytest.raises(ValueError):
            stopping_distance(-1.0, 0.1, 5.0)


class TestLineArray:
    def test_centered_line(self):
        readings = [0.0, 0.0, 1.0, 0.0, 0.0]
        positions = [-2.0, -1.0, 0.0, 1.0, 2.0]
        result = line_array_position(readings, positions)
        assert result == pytest.approx(0.0)

    def test_right_of_center(self):
        readings = [0.0, 0.2, 1.0, 0.4, 0.0]
        positions = [-2.0, -1.0, 0.0, 1.0, 2.0]
        result = line_array_position(readings, positions)
        assert result == pytest.approx(0.125)

    def test_line_lost(self):
        readings = [0.0, 0.0, 0.0, 0.0, 0.0]
        positions = [-2.0, -1.0, 0.0, 1.0, 2.0]
        result = line_array_position(readings, positions, min_sum=0.1)
        assert result is None

    def test_mismatched_lengths_raises(self):
        with pytest.raises(ValueError):
            line_array_position([1.0], [1.0, 2.0])

    def test_nan_reading_raises(self):
        with pytest.raises(ValueError):
            line_array_position([float("nan")], [0.0])

    def test_negative_reading_raises(self):
        with pytest.raises(ValueError):
            line_array_position([-0.5], [0.0])


class TestAngleWrapping:
    def test_zero(self):
        assert wrap_angle(0.0) == pytest.approx(0.0)

    def test_pi(self):
        assert wrap_angle(math.pi) == pytest.approx(math.pi) or \
               wrap_angle(math.pi) == pytest.approx(-math.pi)

    def test_two_pi(self):
        assert wrap_angle(2 * math.pi) == pytest.approx(0.0, abs=1e-10)

    def test_negative_three_pi(self):
        result = wrap_angle(-3 * math.pi)
        assert -math.pi <= result <= math.pi

    def test_heading_error_zero(self):
        assert heading_error(0.0, 0.0) == pytest.approx(0.0)

    def test_heading_error_wrap(self):
        err = heading_error(math.pi * 0.9, -math.pi * 0.9)
        assert abs(err) < math.pi


class TestTimeAwareAlpha:
    def test_small_dt(self):
        alpha = time_aware_alpha(0.01, 0.1)
        assert 0 < alpha < 1

    def test_large_dt(self):
        alpha = time_aware_alpha(10.0, 0.1)
        assert alpha == pytest.approx(1.0, abs=0.01)

    def test_zero_dt(self):
        alpha = time_aware_alpha(0.0, 0.1)
        assert alpha == pytest.approx(0.0, abs=0.001)

    def test_negative_dt_raises(self):
        with pytest.raises(ValueError):
            time_aware_alpha(-0.1, 0.1)

    def test_zero_tau_raises(self):
        with pytest.raises(ValueError):
            time_aware_alpha(0.1, 0.0)


class TestTwoHandSteeringMath:
    def test_horizontal_hands_give_zero_angle(self):
        # Left at (0.3, 0.5), Right at (0.7, 0.5) => horizontal
        angle = compute_two_hand_steering_angle(0.3, 0.5, 0.7, 0.5)
        assert angle == pytest.approx(0.0)

    def test_right_turn_positive_angle(self):
        # Right hand lower (higher y in image coordinates), Left hand higher (lower y)
        # Left at (0.3, 0.4), Right at (0.7, 0.6) => dy = 0.2 > 0 => angle > 0
        angle = compute_two_hand_steering_angle(0.3, 0.4, 0.7, 0.6)
        assert angle > 0.0

    def test_left_turn_negative_angle(self):
        # Left hand lower (higher y), Right hand higher (lower y)
        # Left at (0.3, 0.6), Right at (0.7, 0.4) => dy = -0.2 < 0 => angle < 0
        angle = compute_two_hand_steering_angle(0.3, 0.6, 0.7, 0.4)
        assert angle < 0.0

    def test_normalization_with_neutral(self):
        theta_max = math.radians(45.0)
        # Turn 15 degrees right
        theta_current = math.radians(15.0)
        s = normalize_two_hand_steering(theta_current, theta_neutral=0.0, theta_max=theta_max)
        assert s == pytest.approx(15.0 / 45.0)

    def test_normalization_with_calibrated_neutral(self):
        theta_max = math.radians(45.0)
        # Calibrated neutral is 10 degrees
        theta_neutral = math.radians(10.0)
        # Current is 10 degrees => steering should be zero
        s = normalize_two_hand_steering(math.radians(10.0), theta_neutral=theta_neutral, theta_max=theta_max)
        assert s == pytest.approx(0.0)

        # Current is 25 degrees => relative change is 15 degrees
        s2 = normalize_two_hand_steering(math.radians(25.0), theta_neutral=theta_neutral, theta_max=theta_max)
        assert s2 == pytest.approx(15.0 / 45.0)

    def test_normalization_inversion(self):
        theta_max = math.radians(45.0)
        normal = normalize_two_hand_steering(math.radians(15.0), theta_max=theta_max, invert=False)
        inverted = normalize_two_hand_steering(math.radians(15.0), theta_max=theta_max, invert=True)
        assert inverted == pytest.approx(-normal)

    def test_clamping_at_extreme_angles(self):
        theta_max = math.radians(45.0)
        # 60 degrees turn exceeds 45 degrees max => clamps to +1.0
        s = normalize_two_hand_steering(math.radians(60.0), theta_max=theta_max)
        assert s == pytest.approx(1.0)
        # -60 degrees turn clamps to -1.0
        s_left = normalize_two_hand_steering(math.radians(-60.0), theta_max=theta_max)
        assert s_left == pytest.approx(-1.0)

    def test_hands_too_close_raises(self):
        with pytest.raises(ValueError):
            compute_two_hand_steering_angle(0.5, 0.5, 0.51, 0.5, min_separation=0.05)

    def test_nan_coordinate_raises(self):
        with pytest.raises(ValueError):
            compute_two_hand_steering_angle(float("nan"), 0.5, 0.8, 0.5)

    def test_zero_theta_max_raises(self):
        with pytest.raises(ValueError):
            normalize_two_hand_steering(0.1, 0.0, theta_max=0.0)
