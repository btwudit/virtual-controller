"""Tests for NRL JARVIS Vision — Operating Modes"""

import pytest
from src.modes import ModeManager, OperatingMode


class TestOperatingModes:
    def test_default_mode_is_manual(self):
        manager = ModeManager()
        assert manager.mode == OperatingMode.MANUAL
        assert manager.state.mode == OperatingMode.MANUAL

    def test_switch_mode(self):
        manager = ModeManager()
        assert manager.switch_mode(OperatingMode.OBSTACLE_AVOIDANCE)
        assert manager.mode == OperatingMode.OBSTACLE_AVOIDANCE

    def test_mode_switch_resets_state(self):
        manager = ModeManager()
        manager.update_obstacle(25.0, valid=True)
        assert manager.state.simulated_distance_cm == 25.0

        manager.switch_mode(OperatingMode.LINE_FOLLOWING)
        assert manager.mode == OperatingMode.LINE_FOLLOWING
        # State should be reset to default
        assert manager.state.simulated_distance_cm == 100.0

    def test_vision_autonomy_unconfigured_message(self):
        manager = ModeManager()
        manager.switch_mode(OperatingMode.VISION_AUTONOMY)
        assert manager.state.mode_message == "MODEL NOT CONFIGURED"

    def test_line_lost_message(self):
        manager = ModeManager()
        manager.switch_mode(OperatingMode.LINE_FOLLOWING)
        manager.update_line(detected=False)
        assert manager.state.mode_message == "LINE LOST"

    def test_callback_on_mode_change(self):
        modes_called = []
        manager = ModeManager(on_mode_change=lambda m: modes_called.append(m))
        manager.switch_mode(OperatingMode.OBSTACLE_AVOIDANCE)
        assert modes_called == [OperatingMode.OBSTACLE_AVOIDANCE]
