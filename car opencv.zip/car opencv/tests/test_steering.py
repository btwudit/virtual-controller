"""Tests for the SteeringProcessor."""

import pytest
from src.steering import SteeringProcessor, SteeringConfig


class TestSteeringProcessor:
    def test_center_gives_zero(self):
        proc = SteeringProcessor()
        result = proc.update(320.0, 640.0)
        assert result == pytest.approx(0.0)

    def test_right_gives_positive(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        result = proc.update(480.0, 640.0)
        assert result > 0.0

    def test_left_gives_negative(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        result = proc.update(160.0, 640.0)
        assert result < 0.0

    def test_inversion(self):
        proc_normal = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        proc_invert = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0, invert=True))

        normal = proc_normal.update(400.0, 640.0)
        inverted = proc_invert.update(400.0, 640.0)

        assert inverted == pytest.approx(-normal)

    def test_smoothing(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=0.5, deadband=0.0))
        result1 = proc.update(480.0, 640.0)
        result2 = proc.update(480.0, 640.0)
        assert abs(result2) >= abs(result1)

    def test_reset_clears_state(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=0.5, deadband=0.0))
        proc.update(480.0, 640.0)
        proc.reset()

        assert proc.state.filtered == 0.0
        assert proc.state.output == 0.0

    def test_force_zero(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        proc.update(480.0, 640.0)
        proc.force_zero()

        assert proc.state.output == 0.0
        assert not proc.state.is_valid

    def test_invalid_width_returns_zero(self):
        proc = SteeringProcessor()
        result = proc.update(320.0, 0.0)
        assert result == 0.0
        assert not proc.state.is_valid

    def test_invalid_config_raises(self):
        with pytest.raises(ValueError):
            SteeringProcessor(SteeringConfig(smoothing_alpha=0.0))
        with pytest.raises(ValueError):
            SteeringProcessor(SteeringConfig(deadband=1.0))

    def test_calibrate_center(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        proc.calibrate_center(400.0)
        result = proc.update(400.0, 640.0)
        assert result == pytest.approx(0.0)


from src.tracking_types import HandTrackingResult, SingleHandData, NormalizedPoint


class TestTwoHandSteeringProcessor:
    def _create_two_hand_result(self, lx, ly, rx, ry) -> HandTrackingResult:
        pL = NormalizedPoint(x=lx, y=ly, z=0.0)
        pR = NormalizedPoint(x=rx, y=ry, z=0.0)
        hL = SingleHandData(is_left=True, confidence=0.9, palm_center=pL)
        hR = SingleHandData(is_left=False, confidence=0.9, palm_center=pR)
        return HandTrackingResult(
            hand_detected=True,
            left_hand=hL,
            right_hand=hR,
            both_hands_detected=True,
        )

    def test_level_hands_give_zero_steering(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        res = self._create_two_hand_result(0.3, 0.5, 0.7, 0.5)
        steer = proc.update_two_hand(res)
        assert steer == pytest.approx(0.0)
        assert proc.state.is_valid
        assert proc.state.both_hands_tracked

    def test_right_turn_produces_positive_steering(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        # Left higher, Right lower
        res = self._create_two_hand_result(0.3, 0.4, 0.7, 0.6)
        steer = proc.update_two_hand(res)
        assert steer > 0.0

    def test_left_turn_produces_negative_steering(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        # Left lower, Right higher
        res = self._create_two_hand_result(0.3, 0.6, 0.7, 0.4)
        steer = proc.update_two_hand(res)
        assert steer < 0.0

    def test_either_hand_missing_forces_zero(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        res_valid = self._create_two_hand_result(0.3, 0.4, 0.7, 0.6)
        proc.update_two_hand(res_valid)
        assert proc.state.output > 0.0

        # One hand lost
        res_one_hand = HandTrackingResult(
            hand_detected=True,
            left_hand=SingleHandData(is_left=True, palm_center=NormalizedPoint(0.3, 0.5)),
            right_hand=None,
            both_hands_detected=False,
        )
        steer = proc.update_two_hand(res_one_hand)
        assert steer == 0.0
        assert not proc.state.is_valid
        assert not proc.state.both_hands_tracked

    def test_calibration_workflow(self):
        proc = SteeringProcessor(SteeringConfig(smoothing_alpha=1.0, deadband=0.0))
        proc.start_calibration()

        # Add 5 samples of neutral driving pose (tilt of ~5.7 deg)
        for _ in range(5):
            res = self._create_two_hand_result(0.3, 0.48, 0.7, 0.52)
            assert proc.add_calibration_sample(res)

        assert proc.finish_calibration()
        assert proc.state.is_calibrated

        # Now, entering that exact same pose yields zero steering!
        res_neutral = self._create_two_hand_result(0.3, 0.48, 0.7, 0.52)
        steer = proc.update_two_hand(res_neutral)
        assert steer == pytest.approx(0.0)

    def test_calibration_fails_with_few_samples(self):
        proc = SteeringProcessor()
        proc.start_calibration()
        # Only 1 sample
        res = self._create_two_hand_result(0.3, 0.5, 0.7, 0.5)
        proc.add_calibration_sample(res)
        assert not proc.finish_calibration()
        assert not proc.state.is_calibrated
