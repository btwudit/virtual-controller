"""Tests for the SafetyController."""

import pytest
from src.safety import SafetyController, SafetyState


class TestSafetyInitial:
    def test_starts_disarmed(self):
        ctrl = SafetyController()
        assert ctrl.state == SafetyState.DISARMED

    def test_initial_outputs_zero(self):
        ctrl = SafetyController()
        assert ctrl.status.throttle == 0.0
        assert ctrl.status.steering == 0.0
        assert ctrl.status.left_command == 0.0
        assert ctrl.status.right_command == 0.0

    def test_cannot_output_when_disarmed(self):
        ctrl = SafetyController()
        assert not ctrl.can_output


class TestArming:
    def _make_ready(self, ctrl: SafetyController) -> None:
        ctrl.update_camera(True)
        ctrl.update_tracking(True)

    def test_arm_without_camera_fails(self):
        ctrl = SafetyController()
        ctrl.update_tracking(True)
        assert not ctrl.arm()
        assert ctrl.state == SafetyState.DISARMED

    def test_arm_without_tracking_fails(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        assert not ctrl.arm()

    def test_arm_with_valid_input_succeeds(self):
        ctrl = SafetyController()
        self._make_ready(ctrl)
        assert ctrl.arm()
        assert ctrl.state == SafetyState.READY

    def test_tracking_transitions_to_running(self):
        ctrl = SafetyController()
        self._make_ready(ctrl)
        ctrl.arm()
        ctrl.update_tracking(True)
        assert ctrl.state == SafetyState.RUNNING

    def test_cannot_arm_from_emergency_stop(self):
        ctrl = SafetyController()
        self._make_ready(ctrl)
        ctrl.stop_all()
        assert not ctrl.arm()

    def test_cannot_arm_from_fault(self):
        ctrl = SafetyController()
        self._make_ready(ctrl)
        ctrl.arm()
        ctrl.update_tracking(True)
        ctrl.validate_commands(float("nan"), 0.0, 0.0, 0.0)
        assert ctrl.state == SafetyState.FAULT
        assert not ctrl.arm()


class TestTracking:
    def test_tracking_loss_stops_output(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        assert ctrl.state == SafetyState.RUNNING

        ctrl.update_tracking(False)
        assert ctrl.state == SafetyState.TRACKING_LOST
        assert ctrl.status.left_command == 0.0
        assert ctrl.status.right_command == 0.0


class TestCameraFailure:
    def test_camera_failure_stops_output(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        ctrl.update_camera(False)
        assert ctrl.state == SafetyState.CAMERA_ERROR
        assert ctrl.status.left_command == 0.0


class TestEmergencyStop:
    def test_estop_from_running(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        ctrl.stop_all()
        assert ctrl.state == SafetyState.EMERGENCY_STOP
        assert ctrl.status.throttle == 0.0
        assert ctrl.status.steering == 0.0
        assert ctrl.status.left_command == 0.0
        assert ctrl.status.right_command == 0.0

    def test_estop_from_disarmed(self):
        ctrl = SafetyController()
        ctrl.stop_all()
        assert ctrl.state == SafetyState.EMERGENCY_STOP

    def test_estop_idempotent(self):
        ctrl = SafetyController()
        ctrl.stop_all()
        ctrl.stop_all()
        ctrl.stop_all()
        assert ctrl.state == SafetyState.EMERGENCY_STOP

    def test_mode_change_does_not_rearm(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)
        ctrl.stop_all()
        assert ctrl.state == SafetyState.EMERGENCY_STOP
        ctrl.update_tracking(True)
        assert ctrl.state == SafetyState.EMERGENCY_STOP


class TestDisarm:
    def test_disarm_from_estop(self):
        ctrl = SafetyController()
        ctrl.stop_all()
        assert ctrl.disarm()
        assert ctrl.state == SafetyState.DISARMED

    def test_disarm_from_fault(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)
        ctrl.validate_commands(float("nan"), 0.0, 0.0, 0.0)
        assert ctrl.state == SafetyState.FAULT
        assert ctrl.disarm()
        assert ctrl.state == SafetyState.DISARMED


class TestValidateCommands:
    def test_nan_rejected(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        t, s, l, r = ctrl.validate_commands(float("nan"), 0.0, 0.0, 0.0)
        assert t == 0.0
        assert s == 0.0
        assert l == 0.0
        assert r == 0.0

    def test_inf_rejected(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        t, s, l, r = ctrl.validate_commands(0.0, float("inf"), 0.0, 0.0)
        assert s == 0.0

    def test_valid_commands_pass_when_running(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        t, s, l, r = ctrl.validate_commands(0.3, 0.1, 0.2, 0.4)
        assert t == pytest.approx(0.3)
        assert s == pytest.approx(0.1)

    def test_commands_zeroed_when_not_running(self):
        ctrl = SafetyController()
        t, s, l, r = ctrl.validate_commands(0.5, 0.5, 0.5, 0.5)
        assert t == 0.0
        assert s == 0.0
        assert l == 0.0
        assert r == 0.0


class TestRearmRequiresFreshInput:
    def test_rearm_after_tracking_loss(self):
        ctrl = SafetyController()
        ctrl.update_camera(True)
        ctrl.update_tracking(True)
        ctrl.arm()
        ctrl.update_tracking(True)

        ctrl.update_tracking(False)
        assert ctrl.state == SafetyState.TRACKING_LOST

        ctrl.update_tracking(True)
        assert ctrl.arm()
