"""
NRL JARVIS Vision — Operating Modes

Manages exclusive operating modes for the robotics cockpit.
Exactly one primary mode can be active at a time.
"""

import enum
import logging
from dataclasses import dataclass, field
from typing import Optional, Callable

logger = logging.getLogger(__name__)


class OperatingMode(enum.Enum):
    """Available operating modes."""
    MANUAL = "MANUAL"
    OBSTACLE_AVOIDANCE = "OBSTACLE_AVOIDANCE"
    LINE_FOLLOWING = "LINE_FOLLOWING"
    VISION_AUTONOMY = "VISION_AUTONOMY"


@dataclass
class ModeState:
    """State for the current operating mode."""
    mode: OperatingMode = OperatingMode.MANUAL

    # Obstacle avoidance state
    simulated_distance_cm: float = 100.0
    distance_valid: bool = True

    # Line following state
    line_detected: bool = False
    line_position: float = 0.0
    line_confidence: float = 0.0

    # Vision autonomy state
    model_configured: bool = False
    model_loaded: bool = False
    detection_confidence: float = 0.0
    detection_label: str = ""

    # Common
    mode_message: str = ""


class ModeManager:
    """
    Manages exclusive operating modes.

    Mode changes reset mode-specific state. Mode changes do NOT
    automatically arm the system — arming is a separate operation.
    """

    def __init__(self, on_mode_change: Optional[Callable[[OperatingMode], None]] = None):
        self._state = ModeState()
        self._on_mode_change = on_mode_change
        logger.info(f"ModeManager initialized in {self._state.mode.value} mode")

    @property
    def mode(self) -> OperatingMode:
        return self._state.mode

    @property
    def state(self) -> ModeState:
        return self._state

    def switch_mode(self, new_mode: OperatingMode) -> bool:
        """
        Switch to a new operating mode.
        Resets mode-specific state. Does NOT rearm the system.
        """
        if new_mode == self._state.mode:
            return True

        old_mode = self._state.mode
        logger.info(f"Mode switch: {old_mode.value} -> {new_mode.value}")

        self._state = ModeState(mode=new_mode)

        if new_mode == OperatingMode.VISION_AUTONOMY:
            self._state.mode_message = "MODEL NOT CONFIGURED"
        elif new_mode == OperatingMode.LINE_FOLLOWING:
            self._state.mode_message = "LINE FOLLOWING — SIMULATION"
        elif new_mode == OperatingMode.OBSTACLE_AVOIDANCE:
            self._state.mode_message = "OBSTACLE AVOIDANCE — SIMULATION"
        else:
            self._state.mode_message = "MANUAL CONTROL"

        if self._on_mode_change:
            self._on_mode_change(new_mode)

        return True

    def update_obstacle(
        self,
        distance_cm: float,
        valid: bool = True,
    ) -> None:
        """Update simulated obstacle distance."""
        self._state.simulated_distance_cm = distance_cm
        self._state.distance_valid = valid

    def update_line(
        self,
        detected: bool,
        position: float = 0.0,
        confidence: float = 0.0,
    ) -> None:
        """Update line detection state."""
        self._state.line_detected = detected
        self._state.line_position = position
        self._state.line_confidence = confidence
        if not detected:
            self._state.mode_message = "LINE LOST"

    def update_vision(
        self,
        model_configured: bool = False,
        model_loaded: bool = False,
        confidence: float = 0.0,
        label: str = "",
    ) -> None:
        """Update vision autonomy state."""
        self._state.model_configured = model_configured
        self._state.model_loaded = model_loaded
        self._state.detection_confidence = confidence
        self._state.detection_label = label

        if not model_configured:
            self._state.mode_message = "MODEL NOT CONFIGURED"
        elif not model_loaded:
            self._state.mode_message = "MODEL NOT LOADED"
