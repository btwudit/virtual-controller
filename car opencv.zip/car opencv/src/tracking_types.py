"""
Data structures for hand tracking results.
Supports both single-hand and natural two-hand virtual steering postures.
"""

import time
from dataclasses import dataclass, field
from typing import Optional, List


@dataclass
class NormalizedPoint:
    x: float
    y: float
    z: float = 0.0


@dataclass
class SingleHandData:
    """Detailed landmarks and estimated centers for an individual hand."""
    is_left: Optional[bool] = None  # True if left hand, False if right hand, None if unknown
    confidence: float = 0.0
    landmarks: List[NormalizedPoint] = field(default_factory=list)
    wrist: Optional[NormalizedPoint] = None
    index_tip: Optional[NormalizedPoint] = None
    palm_center: Optional[NormalizedPoint] = None


@dataclass
class HandTrackingResult:
    """
    Standardized tracking result object representing detected hands.
    Contains unified accessors for single-hand fallback and two-hand driving postures.
    """
    hand_detected: bool = False
    
    # Legacy / single hand convenience properties (landmark 8 and 0)
    index_fingertip: Optional[NormalizedPoint] = None
    wrist: Optional[NormalizedPoint] = None
    all_landmarks: List[NormalizedPoint] = field(default_factory=list)
    confidence: float = 0.0
    timestamp: float = field(default_factory=time.monotonic)
    is_left: Optional[bool] = None

    # Dedicated two-hand tracking representations
    left_hand: Optional[SingleHandData] = None
    right_hand: Optional[SingleHandData] = None
    both_hands_detected: bool = False
