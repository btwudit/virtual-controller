"""
NRL JARVIS Vision — Telemetry Module

Reports measured application performance and controller state.
Uses rolling windows for FPS calculation.
"""

import time
import logging
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class TelemetrySnapshot:
    """Point-in-time telemetry data."""
    # Performance
    camera_fps: float = 0.0
    processing_fps: float = 0.0
    ui_fps: float = 0.0
    camera_acquire_ms: float = 0.0
    vision_process_ms: float = 0.0
    controller_compute_ms: float = 0.0
    frame_age_ms: float = 0.0
    
    # Steering
    steering_raw: float = 0.0
    steering_filtered: float = 0.0
    steering_output: float = 0.0
    
    # Throttle & Drive
    throttle: float = 0.0
    left_command: float = 0.0
    right_command: float = 0.0
    
    # Status
    safety_state: str = "DISARMED"
    operating_mode: str = "MANUAL"
    hand_detected: bool = False
    camera_ok: bool = False
    
    # Timing
    app_uptime_s: float = 0.0
    timestamp: float = field(default_factory=time.monotonic)
    
    # Warnings
    warnings: list[str] = field(default_factory=list)


class FPSCounter:
    """
    Rolling FPS counter using a deque of timestamps.
    
    FPS = number_of_frames / elapsed_time_seconds
    Uses a configurable window size to reduce display fluctuations.
    """
    
    def __init__(self, window_size: int = 30):
        self._timestamps: deque[float] = deque(maxlen=window_size)
    
    def tick(self) -> None:
        """Record a frame timestamp."""
        self._timestamps.append(time.monotonic())
    
    @property
    def fps(self) -> float:
        """Current FPS based on rolling window."""
        if len(self._timestamps) < 2:
            return 0.0
        
        elapsed = self._timestamps[-1] - self._timestamps[0]
        if elapsed <= 0:
            return 0.0
        
        return (len(self._timestamps) - 1) / elapsed
    
    def reset(self) -> None:
        """Clear the FPS counter."""
        self._timestamps.clear()


class TelemetryCollector:
    """
    Collects and reports telemetry data from all subsystems.
    
    Provides a thread-safe snapshot mechanism for the UI.
    """
    
    def __init__(self):
        self._app_start_time = time.monotonic()
        self._camera_fps = FPSCounter()
        self._processing_fps = FPSCounter()
        self._ui_fps = FPSCounter()
        self._snapshot = TelemetrySnapshot()
        self._warnings: list[str] = []
        
        # Timing accumulators
        self._last_acquire_ms: float = 0.0
        self._last_vision_ms: float = 0.0
        self._last_controller_ms: float = 0.0
        self._last_frame_age_ms: float = 0.0
    
    def record_camera_frame(self) -> None:
        """Record a camera frame acquisition."""
        self._camera_fps.tick()
    
    def record_processing_frame(self) -> None:
        """Record a vision processing completion."""
        self._processing_fps.tick()
    
    def record_ui_frame(self) -> None:
        """Record a UI update."""
        self._ui_fps.tick()
    
    def record_acquire_time(self, ms: float) -> None:
        self._last_acquire_ms = ms
    
    def record_vision_time(self, ms: float) -> None:
        self._last_vision_ms = ms
    
    def record_controller_time(self, ms: float) -> None:
        self._last_controller_ms = ms
    
    def record_frame_age(self, ms: float) -> None:
        self._last_frame_age_ms = ms
    
    def add_warning(self, warning: str) -> None:
        self._warnings.append(warning)
        if len(self._warnings) > 20:
            self._warnings = self._warnings[-20:]
    
    def clear_warnings(self) -> None:
        self._warnings.clear()
    
    def snapshot(
        self,
        steering_raw: float = 0.0,
        steering_filtered: float = 0.0,
        steering_output: float = 0.0,
        throttle: float = 0.0,
        left_command: float = 0.0,
        right_command: float = 0.0,
        safety_state: str = "DISARMED",
        operating_mode: str = "MANUAL",
        hand_detected: bool = False,
        camera_ok: bool = False,
    ) -> TelemetrySnapshot:
        """Create a telemetry snapshot with current measurements."""
        self._snapshot = TelemetrySnapshot(
            camera_fps=self._camera_fps.fps,
            processing_fps=self._processing_fps.fps,
            ui_fps=self._ui_fps.fps,
            camera_acquire_ms=self._last_acquire_ms,
            vision_process_ms=self._last_vision_ms,
            controller_compute_ms=self._last_controller_ms,
            frame_age_ms=self._last_frame_age_ms,
            steering_raw=steering_raw,
            steering_filtered=steering_filtered,
            steering_output=steering_output,
            throttle=throttle,
            left_command=left_command,
            right_command=right_command,
            safety_state=safety_state,
            operating_mode=operating_mode,
            hand_detected=hand_detected,
            camera_ok=camera_ok,
            app_uptime_s=time.monotonic() - self._app_start_time,
            warnings=list(self._warnings),
        )
        return self._snapshot
    
    @property
    def latest(self) -> TelemetrySnapshot:
        return self._snapshot
