"""
NRL JARVIS Vision — Safety State Machine

Manages application safety state with explicit transitions.
Enforces stop conditions, validates commands, and prevents
unauthorized state changes.
"""

import enum
import math
import time
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


class SafetyState(enum.Enum):
    """Exclusive safety states."""
    DISARMED = "DISARMED"
    READY = "READY"
    RUNNING = "RUNNING"
    TRACKING_LOST = "TRACKING_LOST"
    CAMERA_ERROR = "CAMERA_ERROR"
    SENSOR_ERROR = "SENSOR_ERROR"
    EMERGENCY_STOP = "EMERGENCY_STOP"
    FAULT = "FAULT"


# Legal transitions: from_state -> set of allowed to_states
LEGAL_TRANSITIONS: dict[SafetyState, set[SafetyState]] = {
    SafetyState.DISARMED: {SafetyState.READY, SafetyState.EMERGENCY_STOP, SafetyState.FAULT},
    SafetyState.READY: {SafetyState.RUNNING, SafetyState.DISARMED, SafetyState.EMERGENCY_STOP, SafetyState.CAMERA_ERROR, SafetyState.FAULT},
    SafetyState.RUNNING: {SafetyState.TRACKING_LOST, SafetyState.CAMERA_ERROR, SafetyState.SENSOR_ERROR, SafetyState.EMERGENCY_STOP, SafetyState.DISARMED, SafetyState.FAULT},
    SafetyState.TRACKING_LOST: {SafetyState.READY, SafetyState.DISARMED, SafetyState.EMERGENCY_STOP, SafetyState.CAMERA_ERROR, SafetyState.FAULT},
    SafetyState.CAMERA_ERROR: {SafetyState.DISARMED, SafetyState.EMERGENCY_STOP, SafetyState.FAULT},
    SafetyState.SENSOR_ERROR: {SafetyState.READY, SafetyState.DISARMED, SafetyState.EMERGENCY_STOP, SafetyState.FAULT},
    SafetyState.EMERGENCY_STOP: {SafetyState.DISARMED, SafetyState.FAULT},
    SafetyState.FAULT: {SafetyState.DISARMED},
}


@dataclass
class SafetyStatus:
    """Current safety status snapshot."""
    state: SafetyState = SafetyState.DISARMED
    throttle: float = 0.0
    steering: float = 0.0
    left_command: float = 0.0
    right_command: float = 0.0
    hand_detected: bool = False
    camera_ok: bool = False
    last_valid_frame_time: Optional[float] = None
    last_valid_tracking_time: Optional[float] = None
    last_state_change_time: float = field(default_factory=time.monotonic)
    message: str = ""


class SafetyController:
    """
    Central safety gate for the NRL JARVIS Vision application.

    All command outputs pass through this controller. It can override
    any operating mode to enforce safe operation.
    """

    def __init__(
        self,
        max_frame_age_ms: float = 500.0,
        max_tracking_age_ms: float = 300.0,
    ):
        self._status = SafetyStatus()
        self._max_frame_age_s = max_frame_age_ms / 1000.0
        self._max_tracking_age_s = max_tracking_age_ms / 1000.0
        logger.info("SafetyController initialized in DISARMED state")

    @property
    def state(self) -> SafetyState:
        return self._status.state

    @property
    def status(self) -> SafetyStatus:
        return self._status

    @property
    def is_armed(self) -> bool:
        return self._status.state in (SafetyState.READY, SafetyState.RUNNING)

    @property
    def can_output(self) -> bool:
        """Whether nonzero motor commands are permitted."""
        return self._status.state == SafetyState.RUNNING

    def _transition(self, new_state: SafetyState, message: str = "") -> bool:
        current = self._status.state

        if new_state == current:
            return True

        allowed = LEGAL_TRANSITIONS.get(current, set())
        if new_state not in allowed:
            logger.warning(
                f"Illegal transition: {current.value} -> {new_state.value}"
            )
            return False

        logger.info(
            f"Safety transition: {current.value} -> {new_state.value}"
            + (f" ({message})" if message else "")
        )
        self._status.state = new_state
        self._status.last_state_change_time = time.monotonic()
        self._status.message = message

        if new_state != SafetyState.RUNNING:
            self._zero_outputs()

        return True

    def _zero_outputs(self) -> None:
        """Set all motor commands to zero immediately."""
        self._status.throttle = 0.0
        self._status.steering = 0.0
        self._status.left_command = 0.0
        self._status.right_command = 0.0

    def stop_all(self) -> None:
        """
        Emergency stop — highest priority.
        Sets all outputs to zero and enters EMERGENCY_STOP state.
        Safe to call multiple times (idempotent).
        """
        self._zero_outputs()
        if self._status.state != SafetyState.EMERGENCY_STOP:
            old = self._status.state
            self._status.state = SafetyState.EMERGENCY_STOP
            self._status.last_state_change_time = time.monotonic()
            self._status.message = "EMERGENCY STOP ACTIVATED"
            logger.critical(f"EMERGENCY STOP from {old.value}")
        else:
            logger.debug("Emergency stop repeated (already active)")

    def arm(self) -> bool:
        """
        Attempt to arm the system.
        Requires:
        - Currently DISARMED, TRACKING_LOST, or SENSOR_ERROR
        - Camera is OK
        - Hand is detected (fresh tracking)
        """
        if self._status.state not in (
            SafetyState.DISARMED,
            SafetyState.TRACKING_LOST,
            SafetyState.SENSOR_ERROR,
        ):
            logger.warning(f"Cannot arm from state: {self._status.state.value}")
            return False

        if not self._status.camera_ok:
            logger.warning("Cannot arm: camera not available")
            return False

        if not self._status.hand_detected:
            logger.warning("Cannot arm: hand not detected")
            return False

        now = time.monotonic()
        if self._status.last_valid_tracking_time is not None:
            age = now - self._status.last_valid_tracking_time
            if age > self._max_tracking_age_s:
                logger.warning(f"Cannot arm: tracking data too old ({age:.3f}s)")
                return False
        else:
            logger.warning("Cannot arm: no tracking data yet")
            return False

        return self._transition(SafetyState.READY, "Armed — awaiting RUN")

    def start_running(self) -> bool:
        """Transition from READY to RUNNING."""
        if self._status.state != SafetyState.READY:
            return False
        return self._transition(SafetyState.RUNNING, "Running")

    def disarm(self) -> bool:
        """Disarm the system from appropriate states."""
        self._zero_outputs()
        if self._status.state == SafetyState.FAULT:
            return self._transition(SafetyState.DISARMED, "Fault cleared and disarmed")
        if self._status.state == SafetyState.EMERGENCY_STOP:
            return self._transition(SafetyState.DISARMED, "E-Stop cleared and disarmed")
        return self._transition(SafetyState.DISARMED, "Disarmed by user")

    def update_tracking(self, hand_detected: bool) -> None:
        """
        Update hand tracking status.
        If tracking is lost while RUNNING, transitions to TRACKING_LOST
        and zeros outputs immediately.
        """
        self._status.hand_detected = hand_detected

        if hand_detected:
            self._status.last_valid_tracking_time = time.monotonic()
            if self._status.state == SafetyState.READY:
                self._transition(SafetyState.RUNNING, "Tracking acquired")
        else:
            if self._status.state == SafetyState.RUNNING:
                self._transition(SafetyState.TRACKING_LOST, "Hand tracking lost")

    def update_camera(self, camera_ok: bool) -> None:
        """Update camera status."""
        self._status.camera_ok = camera_ok

        if camera_ok:
            self._status.last_valid_frame_time = time.monotonic()
        else:
            if self._status.state in (
                SafetyState.READY,
                SafetyState.RUNNING,
                SafetyState.TRACKING_LOST,
            ):
                self._transition(SafetyState.CAMERA_ERROR, "Camera failed")

    def validate_commands(
        self,
        throttle: float,
        steering: float,
        left: float,
        right: float,
    ) -> tuple[float, float, float, float]:
        """Central safety gate. Validates and potentially overrides commands."""
        for name, val in [("throttle", throttle), ("steering", steering),
                          ("left", left), ("right", right)]:
            if not math.isfinite(val):
                logger.error(f"Non-finite {name}: {val} — zeroing all outputs")
                self._zero_outputs()
                if self._status.state == SafetyState.RUNNING:
                    self._transition(SafetyState.FAULT, f"Non-finite {name} detected")
                return (0.0, 0.0, 0.0, 0.0)

        now = time.monotonic()
        if self._status.last_valid_frame_time is not None:
            frame_age = now - self._status.last_valid_frame_time
            if frame_age > self._max_frame_age_s and self._status.state == SafetyState.RUNNING:
                self._transition(SafetyState.TRACKING_LOST, f"Frame too old ({frame_age:.3f}s)")

        if not self.can_output:
            self._zero_outputs()
            return (0.0, 0.0, 0.0, 0.0)

        from src.control_math import clamp
        throttle = clamp(throttle, -1.0, 1.0)
        steering = clamp(steering, -1.0, 1.0)
        left = clamp(left, -1.0, 1.0)
        right = clamp(right, -1.0, 1.0)

        self._status.throttle = throttle
        self._status.steering = steering
        self._status.left_command = left
        self._status.right_command = right

        return (throttle, steering, left, right)

    def check_staleness(self) -> None:
        """Periodic staleness check."""
        now = time.monotonic()
        if self._status.state == SafetyState.RUNNING:
            if self._status.last_valid_tracking_time is not None:
                tracking_age = now - self._status.last_valid_tracking_time
                if tracking_age > self._max_tracking_age_s:
                    self._transition(
                        SafetyState.TRACKING_LOST,
                        f"Tracking stale ({tracking_age:.3f}s)"
                    )
