"""
NRL JARVIS Vision — Pure OpenCV Alternative Hand Detector

Fallback hand tracking pipeline using skin-colour thresholding in HSV/YCrCb,
contour analysis, convexity defects, and two-hand spatial partitioning.
Used when MediaPipe's external .task neural network model file is unavailable.
"""

import cv2
import time
import logging
from src.tracking_types import NormalizedPoint, SingleHandData, HandTrackingResult

logger = logging.getLogger(__name__)


class OpenCVHandDetector:
    """
    Geometric/color-based multi-hand tracking using OpenCV contour analysis.
    """

    def __init__(self):
        logger.info("OpenCVHandDetector initialized with multi-hand support.")

    def process(self, frame_bgr) -> HandTrackingResult:
        h, w = frame_bgr.shape[:2]
        now = time.monotonic()

        hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
        ycrcb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2YCrCb)

        mask_hsv = cv2.inRange(hsv, (0, 30, 60), (25, 255, 255))
        mask_ycrcb = cv2.inRange(ycrcb, (0, 133, 77), (255, 173, 127))
        mask = cv2.bitwise_and(mask_hsv, mask_ycrcb)

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.erode(mask, kernel, iterations=1)
        mask = cv2.dilate(mask, kernel, iterations=2)
        mask = cv2.GaussianBlur(mask, (3, 3), 0)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return HandTrackingResult(hand_detected=False, timestamp=now)

        # Filter valid hand-sized contours (> 2500 px area)
        valid_contours = [c for c in contours if cv2.contourArea(c) > 2500]
        if not valid_contours:
            return HandTrackingResult(hand_detected=False, timestamp=now)

        # Sort descending by area, take up to 2
        valid_contours.sort(key=cv2.contourArea, reverse=True)
        detected_hands = []

        for c in valid_contours[:2]:
            topmost = tuple(c[c[:, :, 1].argmin()][0])
            wrist_bottom = tuple(c[c[:, :, 1].argmax()][0])
            M = cv2.moments(c)
            if M["m00"] != 0:
                cx = M["m10"] / M["m00"]
                cy = M["m01"] / M["m00"]
            else:
                cx = (topmost[0] + wrist_bottom[0]) / 2.0
                cy = (topmost[1] + wrist_bottom[1]) / 2.0

            norm_top = NormalizedPoint(x=topmost[0] / float(w), y=topmost[1] / float(h), z=0.0)
            norm_wrist = NormalizedPoint(x=wrist_bottom[0] / float(w), y=wrist_bottom[1] / float(h), z=0.0)
            norm_palm = NormalizedPoint(x=cx / float(w), y=cy / float(h), z=0.0)

            hand = SingleHandData(
                is_left=None,
                confidence=0.85,
                landmarks=[norm_wrist, norm_top],
                wrist=norm_wrist,
                index_tip=norm_top,
                palm_center=norm_palm,
            )
            detected_hands.append(hand)

        left_hand = None
        right_hand = None
        both_detected = len(detected_hands) >= 2

        if both_detected:
            # Sort horizontally: visually left hand has smaller x
            detected_hands.sort(key=lambda h: h.palm_center.x if h.palm_center else 0.0)
            left_hand = detected_hands[0]
            left_hand.is_left = True
            right_hand = detected_hands[1]
            right_hand.is_left = False
        elif len(detected_hands) == 1:
            h_single = detected_hands[0]
            if h_single.palm_center and h_single.palm_center.x < 0.5:
                left_hand = h_single
                left_hand.is_left = True
            else:
                right_hand = h_single
                right_hand.is_left = False

        primary = detected_hands[0]
        return HandTrackingResult(
            hand_detected=True,
            index_fingertip=primary.index_tip,
            wrist=primary.wrist,
            all_landmarks=primary.landmarks,
            confidence=primary.confidence,
            timestamp=now,
            is_left=primary.is_left,
            left_hand=left_hand,
            right_hand=right_hand,
            both_hands_detected=both_detected,
        )
