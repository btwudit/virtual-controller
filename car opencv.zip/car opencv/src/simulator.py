"""
NRL JARVIS Vision — Simulator Module

Simulated robot behaviour and simulated sensors.
All values are clearly labelled as SIMULATED.
Independent of physical robot.
"""

import math
import time
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class SimulatedRobotState:
    """Simulated robot state — NOT real robot data."""
    # Position (arbitrary units)
    x: float = 0.0
    y: float = 0.0
    heading_rad: float = 0.0  # radians, 0 = facing right
    
    # Motor commands (normalized)
    left_command: float = 0.0
    right_command: float = 0.0
    
    # Simulated sensors
    obstacle_distance_cm: float = 100.0
    obstacle_valid: bool = True
    
    # Line sensor (simulated)
    line_readings: list[float] = field(default_factory=lambda: [0.0, 0.0, 1.0, 0.0, 0.0])
    line_positions: list[float] = field(default_factory=lambda: [-2.0, -1.0, 0.0, 1.0, 2.0])
    
    # Status
    is_moving: bool = False
    speed: float = 0.0  # Simulated speed (arbitrary units)
    
    # Timestamps
    last_update: float = field(default_factory=time.monotonic)


class RobotSimulator:
    """
    Simulates simplified 2D robot motion.
    
    WARNING: This is a highly simplified kinematic model.
    It does NOT reproduce actual vehicle dynamics, tire friction,
    motor response curves, or real sensor behaviour.
    All values are SIMULATED.
    """
    
    def __init__(
        self,
        wheel_base: float = 0.3,  # Simulated wheelbase in metres
        max_speed: float = 1.0,    # Simulated max speed in m/s
    ):
        self._state = SimulatedRobotState()
        self._wheel_base = wheel_base
        self._max_speed = max_speed
        logger.info("RobotSimulator initialized (SIMULATED — not real robot)")
    
    @property
    def state(self) -> SimulatedRobotState:
        return self._state
    
    def update(self, left: float, right: float, dt: Optional[float] = None) -> None:
        """
        Update simulated robot state.
        
        Uses differential drive kinematics (simplified).
        
        Args:
            left: Left motor command [-1, +1].
            right: Right motor command [-1, +1].
            dt: Time step in seconds. If None, computed from last update.
        """
        now = time.monotonic()
        if dt is None:
            dt = now - self._state.last_update
        dt = min(dt, 0.1)  # Cap to prevent huge jumps
        
        self._state.left_command = left
        self._state.right_command = right
        self._state.last_update = now
        
        # Convert to simulated velocities
        v_left = left * self._max_speed
        v_right = right * self._max_speed
        
        # Differential drive kinematics
        v = (v_left + v_right) / 2.0
        omega = (v_right - v_left) / self._wheel_base
        
        self._state.speed = abs(v)
        self._state.is_moving = abs(v) > 0.001 or abs(omega) > 0.001
        
        # Update position and heading
        if abs(omega) < 1e-6:
            # Straight line
            self._state.x += v * math.cos(self._state.heading_rad) * dt
            self._state.y += v * math.sin(self._state.heading_rad) * dt
        else:
            # Arc motion
            R = v / omega
            dtheta = omega * dt
            self._state.x += R * (math.sin(self._state.heading_rad + dtheta) - math.sin(self._state.heading_rad))
            self._state.y -= R * (math.cos(self._state.heading_rad + dtheta) - math.cos(self._state.heading_rad))
            self._state.heading_rad += dtheta
        
        # Keep heading in [-pi, pi]
        self._state.heading_rad = math.atan2(
            math.sin(self._state.heading_rad),
            math.cos(self._state.heading_rad)
        )
    
    def set_obstacle_distance(self, distance_cm: float, valid: bool = True) -> None:
        """Set simulated obstacle distance."""
        self._state.obstacle_distance_cm = distance_cm
        self._state.obstacle_valid = valid
    
    def set_line_readings(self, readings: list[float]) -> None:
        """Set simulated line sensor readings."""
        self._state.line_readings = readings
    
    def reset(self) -> None:
        """Reset simulator to initial state."""
        self._state = SimulatedRobotState()
        logger.info("Simulator reset to initial state")
    
    def stop(self) -> None:
        """Stop all simulated motion."""
        self._state.left_command = 0.0
        self._state.right_command = 0.0
        self._state.speed = 0.0
        self._state.is_moving = False
