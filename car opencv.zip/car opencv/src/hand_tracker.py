"""
NRL JARVIS Vision — Hand Tracker Module

Supports both:
1. MediaPipe Tasks HandLandmarker (two-hand tracking with anatomical handedness)
2. High-performance OpenCV Hand Detector Fallback (contour-based two-hand tracking)

Outputs standardized HandTrackingResult with stable left/right hand separation.
"""

import os
import cv2
import time
import logging
from typing import List, Optional, Tuple

import mediapipe as mp
from mediapipe.tasks import python as mp_python
from mediapipe.tasks.python import vision as mp_vision

from src.tracking_types import NormalizedPoint, SingleHandData, HandTrackingResult
from src.opencv_hand_detector import OpenCVHandDetector

logger = logging.getLogger(__name__)

HAND_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (17, 18), (18, 19), (19, 20),
    (0, 17)
]


class HandTracker:
    """
    Unified Hand Tracker supporting two-hand tracking via MediaPipe Tasks
    and OpenCV multi-hand contour fallback.
    """

    def __init__(
        self,
        model_path: str = "models/hand_landmarker.task",
        min_detection_confidence: float = 0.5,
        min_presence_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
        max_num_hands: int = 2,
    ):
        self.model_path = model_path
        self.min_detection_confidence = min_detection_confidence
        self.min_presence_confidence = min_presence_confidence
        self.min_tracking_confidence = min_tracking_confidence
        self.max_num_hands = max_num_hands

        self._detector: Optional[mp_vision.HandLandmarker] = None
        self._opencv_fallback = OpenCVHandDetector()
        self._frame_timestamp_ms: int = 0
        self._using_fallback = False

        self._init_detector()

    def _init_detector(self) -> bool:
        if not os.path.exists(self.model_path) or os.path.getsize(self.model_path) < 1000000:
            logger.info("MediaPipe .task model not available. Using OpenCV vision fallback.")
            self._using_fallback = True
            return True

        try:
            base_options = mp_python.BaseOptions(model_asset_path=self.model_path)
            options = mp_vision.HandLandmarkerOptions(
                base_options=base_options,
                running_mode=mp_vision.RunningMode.VIDEO,
                num_hands=self.max_num_hands,
                min_hand_detection_confidence=self.min_detection_confidence,
                min_hand_presence_confidence=self.min_presence_confidence,
                min_tracking_confidence=self.min_tracking_confidence,
            )
            self._detector = mp_vision.HandLandmarker.create_from_options(options)
            self._using_fallback = False
            logger.info("MediaPipe HandLandmarker initialized with 2-hand support.")
            return True
        except Exception as e:
            logger.warning(f"MediaPipe initialization failed ({e}). Using OpenCV fallback.")
            self._using_fallback = True
            return True

    def is_ready(self) -> bool:
        return self._detector is not None or self._using_fallback

    def process_frame(self, bgr_image, timestamp_s: Optional[float] = None) -> HandTrackingResult:
        now = timestamp_s if timestamp_s is not None else time.monotonic()

        if self._using_fallback or self._detector is None:
            return self._opencv_fallback.process(bgr_image)

        rgb_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_image)
        self._frame_timestamp_ms += 33

        try:
            result = self._detector.detect_for_video(mp_image, self._frame_timestamp_ms)
        except Exception as e:
            logger.error(f"Inference error: {e}")
            return self._opencv_fallback.process(bgr_image)

        if not result.hand_landmarks:
            return HandTrackingResult(hand_detected=False, timestamp=now)

        num_hands = len(result.hand_landmarks)
        parsed_hands: List[SingleHandData] = []

        for i in range(num_hands):
            lms = result.hand_landmarks[i]
            pts = [NormalizedPoint(x=p.x, y=p.y, z=p.z) for p in lms]

            wrist = pts[0] if len(pts) > 0 else None
            index_tip = pts[8] if len(pts) > 8 else None

            # Calculate palm center from wrist(0), index_mcp(5), pinky_mcp(17)
            if len(pts) > 17:
                cx = (pts[0].x + pts[5].x + pts[17].x) / 3.0
                cy = (pts[0].y + pts[5].y + pts[17].y) / 3.0
                cz = (pts[0].z + pts[5].z + pts[17].z) / 3.0
                palm = NormalizedPoint(x=cx, y=cy, z=cz)
            else:
                palm = wrist

            confidence = 0.8
            is_left = None
            if result.handedness and i < len(result.handedness) and len(result.handedness[i]) > 0:
                cat = result.handedness[i][0]
                confidence = cat.score
                # Note: MediaPipe's reported handedness is from user's perspective on unmirrored frames.
                # In mirrored preview, left/right appear reversed horizontally.
                is_left = cat.category_name.lower() == "left"

            hand_data = SingleHandData(
                is_left=is_left,
                confidence=confidence,
                landmarks=pts,
                wrist=wrist,
                index_tip=index_tip,
                palm_center=palm,
            )
            parsed_hands.append(hand_data)

        # Distinguish left and right hand
        left_hand: Optional[SingleHandData] = None
        right_hand: Optional[SingleHandData] = None
        both_detected = num_hands >= 2

        if both_detected:
            # First try anatomical handedness
            h0, h1 = parsed_hands[0], parsed_hands[1]
            if h0.is_left is not None and h1.is_left is not None and h0.is_left != h1.is_left:
                left_hand = h0 if h0.is_left else h1
                right_hand = h1 if h0.is_left else h0
            else:
                # Spatial fallback: Left hand is visually on the left (smaller x)
                sorted_by_x = sorted(parsed_hands, key=lambda h: h.palm_center.x if h.palm_center else 0.0)
                left_hand = sorted_by_x[0]
                left_hand.is_left = True
                right_hand = sorted_by_x[1]
                right_hand.is_left = False
        elif num_hands == 1:
            h_single = parsed_hands[0]
            if h_single.is_left is True:
                left_hand = h_single
            elif h_single.is_left is False:
                right_hand = h_single
            else:
                # Screen position fallback
                if h_single.palm_center and h_single.palm_center.x < 0.5:
                    left_hand = h_single
                    left_hand.is_left = True
                else:
                    right_hand = h_single
                    right_hand.is_left = False

        primary = parsed_hands[0]
        return HandTrackingResult(
            hand_detected=True,
            index_fingertip=primary.index_tip,
            wrist=primary.wrist,
            all_landmarks=primary.landmarks,
            confidence=primary.confidence,
            timestamp=now,
            is_left=primary.is_left,
            left_hand=left_hand,
            right_hand=right_hand,
            both_hands_detected=both_detected,
        )

    def draw_landmarks(self, frame, tracking_result: HandTrackingResult):
        """Draws distinct visual markers for left and right hands with virtual midpoint."""
        if not tracking_result.hand_detected:
            return frame

        h, w = frame.shape[:2]

        def _draw_hand_skeleton(hand: SingleHandData, color: Tuple[int, int, int], label_text: str):
            if not hand or not hand.landmarks:
                return
            pts = [(int(lm.x * w), int(lm.y * h)) for lm in hand.landmarks]

            if len(pts) > 2:
                for s, e in HAND_CONNECTIONS:
                    if s < len(pts) and e < len(pts):
                        cv2.line(frame, pts[s], pts[e], color, 1, cv2.LINE_AA)
                for pt in pts:
                    cv2.circle(frame, pt, 2, color, -1, cv2.LINE_AA)

            # Draw wrist & palm anchor
            if hand.palm_center:
                pc = (int(hand.palm_center.x * w), int(hand.palm_center.y * h))
                cv2.circle(frame, pc, 8, color, 2, cv2.LINE_AA)
                cv2.putText(
                    frame, label_text, (pc[0] - 25, pc[1] - 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1, cv2.LINE_AA
                )

        # Left hand: Electric Cyan (255, 230, 0 in BGR)
        if tracking_result.left_hand:
            _draw_hand_skeleton(tracking_result.left_hand, (238, 210, 0), "LEFT HAND")

        # Right hand: Electric Magenta/Coral (100, 140, 255 in BGR)
        if tracking_result.right_hand:
            _draw_hand_skeleton(tracking_result.right_hand, (100, 140, 255), "RIGHT HAND")

        # If both hands detected, draw steering chord between palm centers
        if (
            tracking_result.both_hands_detected
            and tracking_result.left_hand
            and tracking_result.right_hand
            and tracking_result.left_hand.palm_center
            and tracking_result.right_hand.palm_center
        ):
            p_left = (
                int(tracking_result.left_hand.palm_center.x * w),
                int(tracking_result.left_hand.palm_center.y * h),
            )
            p_right = (
                int(tracking_result.right_hand.palm_center.x * w),
                int(tracking_result.right_hand.palm_center.y * h),
            )
            # Connecting chord
            cv2.line(frame, p_left, p_right, (0, 255, 255), 1, cv2.LINE_AA)
            mid = ((p_left[0] + p_right[0]) // 2, (p_left[1] + p_right[1]) // 2)

            # Draw virtual hub marker at center
            chord_dist = int(((p_right[0] - p_left[0])**2 + (p_right[1] - p_left[1])**2)**0.5)
            wheel_radius = max(25, min(chord_dist // 2, 90))
            cv2.circle(frame, mid, wheel_radius, (0, 255, 255), 1, cv2.LINE_AA)
            cv2.circle(frame, mid, 4, (0, 255, 255), -1, cv2.LINE_AA)

        return frame

    def close(self):
        if self._detector is not None:
            try:
                self._detector.close()
            except Exception:
                pass
            self._detector = None
