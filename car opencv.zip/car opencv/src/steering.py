"""
NRL JARVIS Vision — Steering Processor

Converts hand tracking data (supporting natural two-hand virtual steering)
into filtered steering commands.
Wraps pure control_math functions with state management, multi-sample calibration,
and emergency zeroing.
"""

import math
import time
import logging
from dataclasses import dataclass, field
from typing import Optional, List

from src.control_math import (
    compute_raw_steering,
    compute_two_hand_steering_angle,
    normalize_two_hand_steering,
    exponential_moving_average,
    apply_deadband,
    clamp,
    wrap_angle,
)
from src.tracking_types import HandTrackingResult, SingleHandData

logger = logging.getLogger(__name__)


@dataclass
class SteeringConfig:
    """Steering configuration parameters."""
    invert: bool = False
    center_x: Optional[float] = None
    steering_range: Optional[float] = None
    smoothing_alpha: float = 0.25
    deadband: float = 0.05

    # Two-hand steering parameters
    two_hand_mode: bool = True
    theta_neutral: float = 0.0  # Calibrated neutral angle in radians
    theta_max_deg: float = 45.0  # Max angle for full steering range in degrees
    min_hand_separation: float = 0.05

    def validate(self) -> list[str]:
        """Validate configuration. Returns list of error messages."""
        errors = []
        if not (0 < self.smoothing_alpha <= 1):
            errors.append(f"smoothing_alpha must be in (0, 1]: {self.smoothing_alpha}")
        if not (0 <= self.deadband < 1):
            errors.append(f"deadband must be in [0, 1): {self.deadband}")
        if self.center_x is not None and not math.isfinite(self.center_x):
            errors.append(f"center_x must be finite: {self.center_x}")
        if self.steering_range is not None:
            if not math.isfinite(self.steering_range) or self.steering_range <= 0:
                errors.append(f"steering_range must be positive finite: {self.steering_range}")
        if not math.isfinite(self.theta_neutral):
            errors.append(f"theta_neutral must be finite: {self.theta_neutral}")
        if not math.isfinite(self.theta_max_deg) or self.theta_max_deg <= 0:
            errors.append(f"theta_max_deg must be positive finite: {self.theta_max_deg}")
        return errors


@dataclass
class SteeringState:
    """Current steering processor state."""
    raw: float = 0.0
    filtered: float = 0.0
    output: float = 0.0
    estimated_angle_deg: float = 0.0
    calibrated_neutral_deg: float = 0.0
    is_calibrated: bool = False
    is_valid: bool = False
    both_hands_tracked: bool = False
    last_update_time: float = field(default_factory=time.monotonic)


class SteeringProcessor:
    """
    Processes hand position and two-hand orientation into filtered steering commands.
    """

    def __init__(self, config: Optional[SteeringConfig] = None):
        self._config = config or SteeringConfig()
        self._state = SteeringState()

        errors = self._config.validate()
        if errors:
            raise ValueError(f"Invalid steering config: {'; '.join(errors)}")

        self._state.calibrated_neutral_deg = math.degrees(self._config.theta_neutral)
        self._calib_samples: List[float] = []

        logger.info(
            f"SteeringProcessor initialized: two_hand={self._config.two_hand_mode}, "
            f"theta_max={self._config.theta_max_deg}°, alpha={self._config.smoothing_alpha}"
        )

    @property
    def config(self) -> SteeringConfig:
        return self._config

    @property
    def state(self) -> SteeringState:
        return self._state

    def update_two_hand(self, tracking_result: HandTrackingResult) -> float:
        """
        Processes two-hand tracking data into a natural steering command.

        Requires both left and right hands to be detected.
        If either hand is lost, immediately zeroes output and marks state invalid.
        """
        now = time.monotonic()

        if (
            not tracking_result.both_hands_detected
            or not tracking_result.left_hand
            or not tracking_result.right_hand
            or not tracking_result.left_hand.palm_center
            or not tracking_result.right_hand.palm_center
        ):
            self.force_zero()
            return 0.0

        pL = tracking_result.left_hand.palm_center
        pR = tracking_result.right_hand.palm_center

        try:
            # 1. Compute line orientation angle between hand centers
            angle_rad = compute_two_hand_steering_angle(
                pL.x, pL.y, pR.x, pR.y, min_separation=self._config.min_hand_separation
            )
            angle_deg = math.degrees(angle_rad)

            # 2. Map angle to normalized raw steering
            theta_max_rad = math.radians(self._config.theta_max_deg)
            raw = normalize_two_hand_steering(
                theta_current=angle_rad,
                theta_neutral=self._config.theta_neutral,
                theta_max=theta_max_rad,
                invert=self._config.invert,
            )

            # 3. EMA smoothing
            filtered = exponential_moving_average(
                current_raw=raw,
                previous_filtered=self._state.filtered,
                alpha=self._config.smoothing_alpha,
            )

            # 4. Deadband
            output = apply_deadband(filtered, self._config.deadband)

            # 5. Clamping
            output = clamp(output, -1.0, 1.0)

            # Update state
            self._state.raw = raw
            self._state.filtered = filtered
            self._state.output = output
            self._state.estimated_angle_deg = angle_deg
            self._state.is_valid = True
            self._state.both_hands_tracked = True
            self._state.last_update_time = now

            return output

        except ValueError as e:
            logger.warning(f"Two-hand steering calculation error: {e}")
            self.force_zero()
            return 0.0

    def start_calibration(self) -> None:
        """Begins collecting neutral driving pose samples."""
        self._calib_samples.clear()
        logger.info("Started two-hand steering calibration sample collection.")

    def add_calibration_sample(self, tracking_result: HandTrackingResult) -> bool:
        """
        Adds a sample during calibration.
        Returns True if sample was valid and added, False otherwise.
        """
        if (
            not tracking_result.both_hands_detected
            or not tracking_result.left_hand
            or not tracking_result.right_hand
            or not tracking_result.left_hand.palm_center
            or not tracking_result.right_hand.palm_center
        ):
            return False

        try:
            pL = tracking_result.left_hand.palm_center
            pR = tracking_result.right_hand.palm_center
            angle_rad = compute_two_hand_steering_angle(
                pL.x, pL.y, pR.x, pR.y, min_separation=self._config.min_hand_separation
            )
            self._calib_samples.append(angle_rad)
            return True
        except ValueError:
            return False

    def finish_calibration(self) -> bool:
        """
        Finalizes calibration using the median of collected samples.
        Returns True on success, preserves previous calibration on failure.
        """
        if len(self._calib_samples) < 3:
            logger.warning(f"Calibration failed: insufficient valid samples ({len(self._calib_samples)} < 3)")
            self._calib_samples.clear()
            return False

        # Outlier-resistant median estimator
        sorted_samples = sorted(self._calib_samples)
        mid = len(sorted_samples) // 2
        median_angle = sorted_samples[mid]

        self._config.theta_neutral = median_angle
        self._state.calibrated_neutral_deg = math.degrees(median_angle)
        self._state.is_calibrated = True
        self.reset()
        self._calib_samples.clear()

        logger.info(f"Two-hand calibration complete! Neutral angle set to {self._state.calibrated_neutral_deg:.2f}°")
        return True

    def reset(self) -> None:
        """Reset filter state."""
        self._state.raw = 0.0
        self._state.filtered = 0.0
        self._state.output = 0.0
        self._state.is_valid = False

    def force_zero(self) -> None:
        """Forces output to zero immediately upon tracking loss or safety stop."""
        self._state.raw = 0.0
        self._state.filtered = 0.0
        self._state.output = 0.0
        self._state.is_valid = False
        self._state.both_hands_tracked = False

    # Single-finger legacy update preserved for backwards compatibility with tests
    def update(self, fingertip_x: float, frame_width: float) -> float:
        if not math.isfinite(fingertip_x) or not math.isfinite(frame_width) or frame_width <= 0:
            self._state.is_valid = False
            return 0.0

        try:
            raw = compute_raw_steering(
                fingertip_x=fingertip_x,
                frame_width=frame_width,
                center_x=self._config.center_x,
                steering_range=self._config.steering_range,
                invert=self._config.invert,
            )
            filtered = exponential_moving_average(
                current_raw=raw,
                previous_filtered=self._state.filtered,
                alpha=self._config.smoothing_alpha,
            )
            output = apply_deadband(filtered, self._config.deadband)
            output = clamp(output, -1.0, 1.0)

            self._state.raw = raw
            self._state.filtered = filtered
            self._state.output = output
            self._state.is_valid = True
            return output
        except ValueError:
            self._state.is_valid = False
            return 0.0

    def calibrate_center(self, center_x: float) -> None:
        if math.isfinite(center_x) and center_x > 0:
            self._config.center_x = center_x
