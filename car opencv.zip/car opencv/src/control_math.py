"""
NRL JARVIS Vision — Control Mathematics Module

Pure mathematical functions for steering, throttle mixing, filtering,
obstacle distance, line-following, and stopping distance calculations.
No UI, camera, or hardware dependencies.
"""

import math
from dataclasses import dataclass
from typing import Optional


def clamp(value: float, minimum: float, maximum: float) -> float:
    """Clamp value to [minimum, maximum]. Rejects NaN/Inf."""
    if not math.isfinite(value):
        raise ValueError(f"Cannot clamp non-finite value: {value}")
    if not math.isfinite(minimum) or not math.isfinite(maximum):
        raise ValueError(f"Clamp bounds must be finite: [{minimum}, {maximum}]")
    if minimum > maximum:
        raise ValueError(f"Invalid clamp range: [{minimum}, {maximum}]")
    return max(minimum, min(maximum, value))


def compute_raw_steering(
    fingertip_x: float,
    frame_width: float,
    center_x: Optional[float] = None,
    steering_range: Optional[float] = None,
    invert: bool = False,
) -> float:
    """
    Compute normalized steering from fingertip horizontal position.

    Args:
        fingertip_x: Fingertip x position in pixels.
        frame_width: Frame width in pixels. Must be > 0.
        center_x: Optional calibrated center. Defaults to frame_width / 2.
        steering_range: Optional half-range for normalization. Defaults to frame_width / 2.
        invert: If True, negate the steering value.

    Returns:
        Normalized steering in [-1.0, +1.0].
        -1.0 = full left, 0.0 = center, +1.0 = full right.

    Raises:
        ValueError: If inputs are non-finite or frame_width <= 0.
    """
    if not math.isfinite(fingertip_x):
        raise ValueError(f"fingertip_x must be finite: {fingertip_x}")
    if not math.isfinite(frame_width) or frame_width <= 0:
        raise ValueError(f"frame_width must be positive finite: {frame_width}")

    x_c = center_x if center_x is not None else frame_width / 2.0
    R = steering_range if steering_range is not None else frame_width / 2.0

    if not math.isfinite(x_c):
        raise ValueError(f"center_x must be finite: {x_c}")
    if not math.isfinite(R) or R <= 0:
        raise ValueError(f"steering_range must be positive finite: {R}")

    s_raw = clamp((fingertip_x - x_c) / R, -1.0, 1.0)

    if invert:
        s_raw = -s_raw

    return s_raw


def exponential_moving_average(
    current_raw: float,
    previous_filtered: float,
    alpha: float,
) -> float:
    """
    Exponential moving average filter.

    s_filtered[t] = alpha * s_raw[t] + (1 - alpha) * s_filtered[t-1]

    Args:
        current_raw: Current raw value.
        previous_filtered: Previous filtered value.
        alpha: Smoothing factor in (0, 1].

    Returns:
        Filtered value.

    Raises:
        ValueError: If alpha not in (0, 1] or inputs non-finite.
    """
    if not math.isfinite(current_raw):
        raise ValueError(f"current_raw must be finite: {current_raw}")
    if not math.isfinite(previous_filtered):
        raise ValueError(f"previous_filtered must be finite: {previous_filtered}")
    if not math.isfinite(alpha) or alpha <= 0 or alpha > 1:
        raise ValueError(f"alpha must be in (0, 1]: {alpha}")

    return alpha * current_raw + (1.0 - alpha) * previous_filtered


def time_aware_alpha(delta_t: float, tau: float) -> float:
    """
    Compute time-aware smoothing alpha.

    alpha_dt = 1 - exp(-delta_t / tau)

    Args:
        delta_t: Elapsed time in seconds. Must be >= 0.
        tau: Smoothing time constant in seconds. Must be > 0.

    Returns:
        Alpha value in (0, 1].
    """
    if not math.isfinite(delta_t) or delta_t < 0:
        raise ValueError(f"delta_t must be non-negative finite: {delta_t}")
    if not math.isfinite(tau) or tau <= 0:
        raise ValueError(f"tau must be positive finite: {tau}")

    alpha = 1.0 - math.exp(-delta_t / tau)
    return clamp(alpha, 1e-9, 1.0)


def apply_deadband(value: float, deadband: float) -> float:
    """
    Apply deadband — values within deadband become zero.

    Args:
        value: Input value.
        deadband: Deadband threshold in [0, 1).

    Returns:
        Zero if abs(value) < deadband, otherwise value unchanged.
    """
    if not math.isfinite(value):
        raise ValueError(f"value must be finite: {value}")
    if not math.isfinite(deadband) or deadband < 0 or deadband >= 1:
        raise ValueError(f"deadband must be in [0, 1): {deadband}")

    if abs(value) < deadband:
        return 0.0
    return value


@dataclass(frozen=True)
class DifferentialDriveOutput:
    """Normalized left and right motor commands."""
    left: float
    right: float


def differential_drive_mix(throttle: float, steering: float) -> DifferentialDriveOutput:
    """
    Differential drive mixing.

    left_raw  = throttle - steering
    right_raw = throttle + steering

    Both outputs are normalized to [-1, +1] preserving the ratio.

    Sign convention:
    - Positive throttle = forward.
    - Positive steering = turn right (right motor receives more power/left slows or right turns vehicle right).
      According to project prompt specification:
      left_raw = v - s
      right_raw = v + s
      m = max(1.0, abs(left_raw), abs(right_raw))
      left = left_raw / m
      right = right_raw / m

    Args:
        throttle: Normalized throttle in [-1, +1].
        steering: Normalized steering in [-1, +1].

    Returns:
        DifferentialDriveOutput with left and right in [-1, +1].

    Raises:
        ValueError: If inputs are non-finite.
    """
    if not math.isfinite(throttle):
        raise ValueError(f"throttle must be finite: {throttle}")
    if not math.isfinite(steering):
        raise ValueError(f"steering must be finite: {steering}")

    throttle = clamp(throttle, -1.0, 1.0)
    steering = clamp(steering, -1.0, 1.0)

    left_raw = throttle - steering
    right_raw = throttle + steering

    m = max(1.0, abs(left_raw), abs(right_raw))

    left = left_raw / m
    right = right_raw / m

    return DifferentialDriveOutput(left=left, right=right)


def ramp_limit(
    target: float,
    previous: float,
    delta_t: float,
    accel_rate: float,
    decel_rate: float,
) -> float:
    """
    Time-aware ramp limiter.
    Limits the rate of change of a command value.
    """
    if not math.isfinite(target):
        raise ValueError(f"target must be finite: {target}")
    if not math.isfinite(previous):
        raise ValueError(f"previous must be finite: {previous}")
    if not math.isfinite(delta_t) or delta_t < 0:
        raise ValueError(f"delta_t must be non-negative finite: {delta_t}")
    if not math.isfinite(accel_rate) or accel_rate <= 0:
        raise ValueError(f"accel_rate must be positive finite: {accel_rate}")
    if not math.isfinite(decel_rate) or decel_rate <= 0:
        raise ValueError(f"decel_rate must be positive finite: {decel_rate}")

    delta_t = min(delta_t, 1.0)
    diff = target - previous

    if abs(target) >= abs(previous):
        rate = accel_rate
    else:
        rate = decel_rate

    max_change = rate * delta_t
    clamped_diff = clamp(diff, -max_change, max_change)

    result = previous + clamped_diff
    return clamp(result, -1.0, 1.0)


def echo_to_distance_m(echo_time_s: float, speed_of_sound_mps: float = 343.0) -> float:
    """
    Convert ultrasonic echo time to distance in metres.
    distance = speed_of_sound * echo_time / 2
    """
    if not math.isfinite(echo_time_s) or echo_time_s < 0:
        raise ValueError(f"echo_time_s must be non-negative finite: {echo_time_s}")
    if not math.isfinite(speed_of_sound_mps) or speed_of_sound_mps <= 0:
        raise ValueError(f"speed_of_sound_mps must be positive finite: {speed_of_sound_mps}")

    return speed_of_sound_mps * echo_time_s / 2.0


def distance_to_cm(distance_m: float) -> float:
    """Convert metres to centimetres."""
    if not math.isfinite(distance_m):
        raise ValueError(f"distance_m must be finite: {distance_m}")
    return distance_m * 100.0


def obstacle_throttle_limit(
    distance_cm: float,
    min_distance_cm: float,
    safe_distance_cm: float,
    max_throttle: float,
) -> float:
    """
    Compute throttle limit based on obstacle distance.
    - distance <= min_distance: throttle_limit = 0
    - distance >= safe_distance: throttle_limit = max_throttle
    - In between: linear interpolation
    """
    if not math.isfinite(distance_cm) or distance_cm < 0:
        raise ValueError(f"distance_cm must be non-negative finite: {distance_cm}")
    if not math.isfinite(min_distance_cm) or min_distance_cm < 0:
        raise ValueError(f"min_distance_cm must be non-negative finite: {min_distance_cm}")
    if not math.isfinite(safe_distance_cm) or safe_distance_cm <= min_distance_cm:
        raise ValueError(f"safe_distance_cm must be > min_distance_cm: {safe_distance_cm}")
    if not math.isfinite(max_throttle) or max_throttle <= 0:
        raise ValueError(f"max_throttle must be positive finite: {max_throttle}")

    if distance_cm <= min_distance_cm:
        return 0.0
    if distance_cm >= safe_distance_cm:
        return max_throttle

    factor = (distance_cm - min_distance_cm) / (safe_distance_cm - min_distance_cm)
    return max_throttle * clamp(factor, 0.0, 1.0)


def stopping_distance(
    speed_mps: float,
    reaction_time_s: float,
    braking_decel_mps2: float,
    safety_margin_m: float = 0.0,
) -> float:
    """
    Compute theoretical stopping distance (ILLUSTRATIVE, NOT CALIBRATED).
    d_stop = v * t_reaction + v² / (2 * a) + margin
    """
    if not math.isfinite(speed_mps) or speed_mps < 0:
        raise ValueError(f"speed_mps must be non-negative finite: {speed_mps}")
    if not math.isfinite(reaction_time_s) or reaction_time_s < 0:
        raise ValueError(f"reaction_time_s must be non-negative finite: {reaction_time_s}")
    if not math.isfinite(braking_decel_mps2) or braking_decel_mps2 <= 0:
        raise ValueError(f"braking_decel_mps2 must be positive finite: {braking_decel_mps2}")
    if not math.isfinite(safety_margin_m) or safety_margin_m < 0:
        raise ValueError(f"safety_margin_m must be non-negative finite: {safety_margin_m}")

    reaction_dist = speed_mps * reaction_time_s
    braking_dist = (speed_mps ** 2) / (2.0 * braking_decel_mps2)

    return reaction_dist + braking_dist + safety_margin_m


def line_array_position(
    readings: list[float],
    positions: list[float],
    min_sum: float = 0.1,
) -> Optional[float]:
    """
    Compute weighted line position from sensor array.
    e = sum(p_i * r_i) / sum(r_i)
    """
    if len(readings) != len(positions):
        raise ValueError("readings and positions must have same length")
    if len(readings) == 0:
        return None
    if not math.isfinite(min_sum) or min_sum < 0:
        raise ValueError(f"min_sum must be non-negative finite: {min_sum}")

    total = 0.0
    weighted = 0.0

    for r, p in zip(readings, positions):
        if not math.isfinite(r) or not math.isfinite(p):
            raise ValueError("All readings and positions must be finite")
        if r < 0:
            raise ValueError(f"Readings must be non-negative: {r}")
        total += r
        weighted += p * r

    if total < min_sum:
        return None

    return weighted / total


def wrap_angle(angle_rad: float) -> float:
    """Wrap angle to [-pi, +pi]."""
    if not math.isfinite(angle_rad):
        raise ValueError(f"angle_rad must be finite: {angle_rad}")

    result = math.fmod(angle_rad + math.pi, 2 * math.pi)
    if result < 0:
        result += 2 * math.pi
    return result - math.pi


def heading_error(target_rad: float, current_rad: float) -> float:
    """Compute wrapped heading error (shortest angular distance)."""
    if not math.isfinite(target_rad) or not math.isfinite(current_rad):
        raise ValueError("Heading values must be finite")
    return wrap_angle(target_rad - current_rad)


# =========================================================================
# Two-Hand Virtual Steering Calculations
# =========================================================================

def compute_two_hand_steering_angle(
    left_x: float,
    left_y: float,
    right_x: float,
    right_y: float,
    min_separation: float = 0.05,
) -> float:
    """
    Compute the angle of the line connecting left and right hand centers.

    Coordinates are in normalized image space (x right, y down):
    - Left hand: (left_x, left_y)
    - Right hand: (right_x, right_y)

    dx = right_x - left_x
    dy = right_y - left_y

    When both hands are level horizontally:
        dy = 0, dx > 0 => angle = 0 radians.
    When turning right:
        left hand goes UP (y decreases), right hand goes DOWN (y increases) => dy > 0 => angle > 0 (positive).
    When turning left:
        left hand goes DOWN (y increases), right hand goes UP (y decreases) => dy < 0 => angle < 0 (negative).

    Args:
        left_x, left_y: Normalized coordinates of left hand center.
        right_x, right_y: Normalized coordinates of right hand center.
        min_separation: Minimum Euclidean distance between hands to prevent degenerate angle calculations.

    Returns:
        Steering angle in radians in [-pi, +pi].

    Raises:
        ValueError: If coordinates are non-finite or hands are too close / swapped.
    """
    for name, val in [("left_x", left_x), ("left_y", left_y), ("right_x", right_x), ("right_y", right_y)]:
        if not math.isfinite(val):
            raise ValueError(f"{name} must be finite: {val}")

    dx = right_x - left_x
    dy = right_y - left_y
    dist = math.hypot(dx, dy)

    if dist < min_separation:
        raise ValueError(f"Hands too close for reliable orientation: dist={dist:.4f} < {min_separation}")

    # Angle of the chord
    return math.atan2(dy, dx)


def normalize_two_hand_steering(
    theta_current: float,
    theta_neutral: float = 0.0,
    theta_max: float = math.radians(45.0),
    invert: bool = False,
) -> float:
    """
    Map estimated relative steering angle into a normalized command [-1.0, +1.0].

    delta_theta = wrap_angle(theta_current - theta_neutral)
    s_raw = clamp(delta_theta / theta_max, -1.0, +1.0)

    Args:
        theta_current: Current estimated steering angle in radians.
        theta_neutral: Calibrated neutral steering angle in radians.
        theta_max: Maximum steering angle scale in radians (must be > 0).
        invert: If True, invert the steering command.

    Returns:
        Normalized steering in [-1.0, +1.0].
        -1.0 = maximum left, 0.0 = centered, +1.0 = maximum right.

    Raises:
        ValueError: If angles are non-finite or theta_max <= 0.
    """
    if not math.isfinite(theta_current):
        raise ValueError(f"theta_current must be finite: {theta_current}")
    if not math.isfinite(theta_neutral):
        raise ValueError(f"theta_neutral must be finite: {theta_neutral}")
    if not math.isfinite(theta_max) or theta_max <= 0:
        raise ValueError(f"theta_max must be positive finite: {theta_max}")

    delta_theta = wrap_angle(theta_current - theta_neutral)
    s_raw = clamp(delta_theta / theta_max, -1.0, 1.0)

    if invert:
        s_raw = -s_raw

    return s_raw
