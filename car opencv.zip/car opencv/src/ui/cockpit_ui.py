"""
NRL JARVIS Vision — Cockpit UI (Tkinter Desktop Engine)

Dark graphite background, electric cyan and blue highlights, technical typography,
clean telemetry dashboard, animated indicators, two-hand virtual steering wheel,
live camera panel with dual-hand HUD markers, emergency stop, and mode controls.
"""

import math
import time
import tkinter as tk
from tkinter import ttk, messagebox
import cv2
import numpy as np
from PIL import Image, ImageTk

from src.camera import CameraManager, CameraConfig
from src.hand_tracker import HandTracker
from src.steering import SteeringProcessor, SteeringConfig
from src.safety import SafetyController, SafetyState
from src.modes import ModeManager, OperatingMode
from src.simulator import RobotSimulator
from src.telemetry import TelemetryCollector
from src.control_math import differential_drive_mix


class JarvisCockpitUI:
    """
    JARVIS Robotics Cockpit Desktop Application with Two-Hand Virtual Steering.
    """

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("NRL JARVIS VISION — TWO-HAND VIRTUAL STEERING COCKPIT")
        self.root.geometry("1280x820")
        self.root.configure(bg="#0B0E14")

        # Core subsystems
        self.camera = CameraManager(CameraConfig())
        self.tracker = HandTracker()
        self.steering_proc = SteeringProcessor()
        self.safety = SafetyController()
        self.modes = ModeManager()
        self.simulator = RobotSimulator()
        self.telemetry = TelemetryCollector()

        self._running = True
        self._target_throttle = 0.0

        # Calibration state
        self._is_calibrating = False
        self._calib_start_time = 0.0
        self._calib_duration_s = 2.0  # Collect samples for 2 seconds

        self._init_styles()
        self._build_layout()
        self._bind_keys()

        # Start camera
        self.camera.open()

        # Update loop (~30 fps)
        self.root.after(33, self._main_loop)

    def _init_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background="#0B0E14")
        style.configure("Header.TLabel", background="#0B0E14", foreground="#00E5FF", font=("Consolas", 14, "bold"))
        style.configure("SubHeader.TLabel", background="#0B0E14", foreground="#78909C", font=("Consolas", 10))
        style.configure("TeleValue.TLabel", background="#121824", foreground="#00E5FF", font=("Consolas", 11, "bold"))
        style.configure("TeleLabel.TLabel", background="#121824", foreground="#546E7A", font=("Consolas", 9))

    def _build_layout(self):
        # 1. TOP HEADER BAR
        top_bar = tk.Frame(self.root, bg="#121824", height=50, bd=1, relief="ridge")
        top_bar.pack(side="top", fill="x", padx=10, pady=5)

        title_lbl = tk.Label(
            top_bar, text="◈ NRL JARVIS VISION // TWO-HAND COCKPIT",
            fg="#00E5FF", bg="#121824", font=("Consolas", 13, "bold")
        )
        title_lbl.pack(side="left", padx=15, pady=8)

        self.lbl_header_mode = tk.Label(top_bar, text="MODE: MANUAL", fg="#64B5F6", bg="#121824", font=("Consolas", 11, "bold"))
        self.lbl_header_mode.pack(side="left", padx=25)

        self.lbl_header_state = tk.Label(top_bar, text="STATE: DISARMED", fg="#FFB74D", bg="#121824", font=("Consolas", 11, "bold"))
        self.lbl_header_state.pack(side="left", padx=15)

        self.lbl_fps = tk.Label(top_bar, text="FPS: 00.0", fg="#80CBC4", bg="#121824", font=("Consolas", 10))
        self.lbl_fps.pack(side="right", padx=15)

        # 2. MAIN WORKSPACE (Split Left / Center / Right)
        workspace = tk.Frame(self.root, bg="#0B0E14")
        workspace.pack(side="top", fill="both", expand=True, padx=10, pady=5)

        # --- LEFT PANEL: CAMERA VIEW ---
        left_panel = tk.Frame(workspace, bg="#121824", bd=1, relief="solid")
        left_panel.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        tk.Label(
            left_panel, text="LIVE DUAL-HAND VISION FEED & GESTURE SKELETONS",
            fg="#00E5FF", bg="#121824", font=("Consolas", 10, "bold")
        ).pack(anchor="w", padx=10, pady=5)

        self.canvas_camera = tk.Canvas(left_panel, bg="#05070A", width=520, height=390, highlightthickness=1, highlightbackground="#1E293B")
        self.canvas_camera.pack(padx=10, pady=5, fill="both", expand=True)

        cam_info_bar = tk.Frame(left_panel, bg="#121824")
        cam_info_bar.pack(fill="x", padx=10, pady=5)
        self.lbl_tracking_status = tk.Label(cam_info_bar, text="TRACKING: WAITING FOR BOTH HANDS", fg="#FFB74D", bg="#121824", font=("Consolas", 9, "bold"))
        self.lbl_tracking_status.pack(side="left")

        # Hand indicators (L and R tags)
        self.lbl_hands_indicator = tk.Label(cam_info_bar, text="L: -- | R: --", fg="#78909C", bg="#121824", font=("Consolas", 9, "bold"))
        self.lbl_hands_indicator.pack(side="right", padx=10)

        # --- CENTER PANEL: VIRTUAL STEERING WHEEL & SIMULATOR ---
        center_panel = tk.Frame(workspace, bg="#121824", width=380, bd=1, relief="solid")
        center_panel.pack(side="left", fill="both", padx=5, pady=5)

        tk.Label(center_panel, text="VIRTUAL STEERING WHEEL & TELEMETRY", fg="#00E5FF", bg="#121824", font=("Consolas", 10, "bold")).pack(anchor="w", padx=10, pady=5)

        self.canvas_wheel = tk.Canvas(center_panel, bg="#0B0E14", width=340, height=220, highlightthickness=0)
        self.canvas_wheel.pack(padx=10, pady=5)

        # Throttle Slider
        throttle_frame = tk.Frame(center_panel, bg="#121824")
        throttle_frame.pack(fill="x", padx=15, pady=4)
        tk.Label(throttle_frame, text="THROTTLE SETPOINT", fg="#64B5F6", bg="#121824", font=("Consolas", 9, "bold")).pack(anchor="w")

        self.slider_throttle = tk.Scale(
            throttle_frame, from_=-1.0, to=1.0, resolution=0.05, orient="horizontal",
            bg="#121824", fg="#00E5FF", troughcolor="#05070A", highlightthickness=0,
            command=self._on_throttle_slider
        )
        self.slider_throttle.set(0.0)
        self.slider_throttle.pack(fill="x", pady=2)

        # 2D Kinematic Simulator Display
        tk.Label(center_panel, text="SIMULATED ROBOT KINEMATICS", fg="#546E7A", bg="#121824", font=("Consolas", 9, "bold")).pack(anchor="w", padx=15, pady=(8, 0))
        self.canvas_sim = tk.Canvas(center_panel, bg="#05070A", width=340, height=120, highlightthickness=1, highlightbackground="#1E293B")
        self.canvas_sim.pack(padx=10, pady=5)

        # --- RIGHT PANEL: SAFETY, CALIBRATION, AND OPERATING CONTROLS ---
        right_panel = tk.Frame(workspace, bg="#121824", width=280, bd=1, relief="solid")
        right_panel.pack(side="right", fill="both", padx=5, pady=5)

        tk.Label(right_panel, text="SAFETY & CALIBRATION", fg="#00E5FF", bg="#121824", font=("Consolas", 10, "bold")).pack(anchor="w", padx=10, pady=5)

        # Emergency Stop Button (Prominent & High Contrast)
        self.btn_estop = tk.Button(
            right_panel, text="⛔ EMERGENCY STOP (SPACE)", bg="#D32F2F", fg="#FFFFFF",
            font=("Consolas", 11, "bold"), activebackground="#B71C1C", activeforeground="#FFFFFF",
            bd=3, relief="raised", command=self._on_estop
        )
        self.btn_estop.pack(fill="x", padx=15, pady=8)

        # Arm & Disarm Buttons
        arm_frame = tk.Frame(right_panel, bg="#121824")
        arm_frame.pack(fill="x", padx=15, pady=4)

        self.btn_arm = tk.Button(
            arm_frame, text="ARM SYSTEM (A)", bg="#1976D2", fg="#FFFFFF",
            font=("Consolas", 9, "bold"), activebackground="#0288D1", command=self._on_arm
        )
        self.btn_arm.pack(side="left", fill="x", expand=True, padx=2)

        self.btn_disarm = tk.Button(
            arm_frame, text="DISARM (D)", bg="#37474F", fg="#ECEFF1",
            font=("Consolas", 9, "bold"), activebackground="#455A64", command=self._on_disarm
        )
        self.btn_disarm.pack(side="right", fill="x", expand=True, padx=2)

        # Two-Hand Steering Calibration System
        calib_box = tk.LabelFrame(right_panel, text="STEERING CALIBRATION", fg="#64B5F6", bg="#121824", font=("Consolas", 9, "bold"))
        calib_box.pack(fill="x", padx=15, pady=8)

        self.btn_calib = tk.Button(
            calib_box, text="🎯 CALIBRATE NEUTRAL POSE", bg="#263238", fg="#00E5FF",
            font=("Consolas", 9, "bold"), activebackground="#37474F", activeforeground="#00E5FF",
            command=self._start_calibration
        )
        self.btn_calib.pack(fill="x", padx=10, pady=6)

        self.lbl_calib_status = tk.Label(calib_box, text="STATUS: UNCALIBRATED (DEFAULT)", fg="#78909C", bg="#121824", font=("Consolas", 8))
        self.lbl_calib_status.pack(anchor="w", padx=10, pady=2)

        # Steering Sensitivity & Inversion Controls
        ctrls_box = tk.LabelFrame(right_panel, text="STEERING TUNING", fg="#64B5F6", bg="#121824", font=("Consolas", 9, "bold"))
        ctrls_box.pack(fill="x", padx=15, pady=8)

        self.invert_var = tk.BooleanVar(value=False)
        self.chk_invert = tk.Checkbutton(
            ctrls_box, text="INVERT STEERING", variable=self.invert_var,
            bg="#121824", fg="#ECEFF1", selectcolor="#05070A",
            activebackground="#121824", activeforeground="#00E5FF", font=("Consolas", 8),
            command=self._on_toggle_invert
        )
        self.chk_invert.pack(anchor="w", padx=10, pady=2)

        # Operating Mode Radio Buttons
        mode_box = tk.LabelFrame(right_panel, text="OPERATING MODE", fg="#64B5F6", bg="#121824", font=("Consolas", 9, "bold"))
        mode_box.pack(fill="x", padx=15, pady=8)

        self.mode_var = tk.StringVar(value="MANUAL")
        for mode in OperatingMode:
            rb = tk.Radiobutton(
                mode_box, text=mode.value.replace("_", " "), variable=self.mode_var,
                value=mode.value, bg="#121824", fg="#ECEFF1", selectcolor="#05070A",
                activebackground="#121824", activeforeground="#00E5FF", font=("Consolas", 8),
                command=self._on_mode_selected
            )
            rb.pack(anchor="w", padx=10, pady=2)

        # 3. BOTTOM TELEMETRY BAR
        bottom_bar = tk.Frame(self.root, bg="#121824", height=80, bd=1, relief="ridge")
        bottom_bar.pack(side="bottom", fill="x", padx=10, pady=5)

        metrics = [
            ("ESTIMATED ANGLE", "lbl_steer_angle"),
            ("NORMALIZED STEER", "lbl_filt_steer"),
            ("LEFT MOTOR", "lbl_left_motor"),
            ("RIGHT MOTOR", "lbl_right_motor"),
            ("OBSTACLE DIST", "lbl_dist"),
            ("UPTIME", "lbl_uptime"),
        ]

        self.tele_labels = {}
        for idx, (label, key) in enumerate(metrics):
            cell = tk.Frame(bottom_bar, bg="#121824")
            cell.pack(side="left", fill="both", expand=True, padx=5, pady=4)

            tk.Label(cell, text=label, fg="#546E7A", bg="#121824", font=("Consolas", 8)).pack(anchor="w")
            lbl_val = tk.Label(cell, text="0.00", fg="#00E5FF", bg="#121824", font=("Consolas", 10, "bold"))
            lbl_val.pack(anchor="w")
            self.tele_labels[key] = lbl_val

    def _bind_keys(self):
        self.root.bind("<space>", lambda e: self._on_estop())
        self.root.bind("<a>", lambda e: self._on_arm())
        self.root.bind("<d>", lambda e: self._on_disarm())
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _on_throttle_slider(self, val):
        self._target_throttle = float(val)

    def _on_toggle_invert(self):
        self.steering_proc.config.invert = self.invert_var.get()

    def _start_calibration(self):
        self.steering_proc.start_calibration()
        self._is_calibrating = True
        self._calib_start_time = time.monotonic()
        self.btn_calib.config(text="HOLD STILL (2.0s)...", bg="#F57C00", fg="#FFFFFF")
        self.lbl_calib_status.config(text="COLLECTING DUAL-HAND SAMPLES...", fg="#FFA726")

    def _on_estop(self):
        self.safety.stop_all()
        self.slider_throttle.set(0.0)
        self._target_throttle = 0.0
        self.simulator.stop()
        self.steering_proc.force_zero()

    def _on_arm(self):
        self.safety.arm()

    def _on_disarm(self):
        self.safety.disarm()
        self.slider_throttle.set(0.0)
        self._target_throttle = 0.0
        self.steering_proc.reset()

    def _on_mode_selected(self):
        chosen = OperatingMode(self.mode_var.get())
        self.modes.switch_mode(chosen)
        self.steering_proc.reset()

    def _draw_virtual_wheel(self, steering_val: float, angle_deg: float, is_active: bool):
        """
        Renders a realistic, styled virtual steering wheel.
        Includes circular rim, center hub, horizontal & vertical spokes, and alignment marker.
        """
        self.canvas_wheel.delete("all")
        cx, cy = 170, 105
        outer_r = 72
        inner_r = 58
        hub_r = 18

        # Color palette depending on state
        if self.safety.state == SafetyState.EMERGENCY_STOP:
            rim_color = "#E53935"
            accent_color = "#FF5252"
        elif not is_active:
            rim_color = "#1E293B"
            accent_color = "#475569"
        else:
            rim_color = "#0284C7"
            accent_color = "#00E5FF"

        # 1. Background grid rings
        self.canvas_wheel.create_oval(cx - outer_r - 12, cy - outer_r - 12, cx + outer_r + 12, cy + outer_r + 12, outline="#0F172A", width=1)
        self.canvas_wheel.create_oval(cx - outer_r, cy - outer_r, cx + outer_r, cy + outer_r, outline=rim_color, width=7)
        self.canvas_wheel.create_oval(cx - inner_r, cy - inner_r, cx + inner_r, cy + inner_r, outline="#0B0E14", width=2)

        # 2. Fixed Neutral Marker (12 o'clock notch)
        self.canvas_wheel.create_line(cx, cy - outer_r - 14, cx, cy - outer_r + 4, fill="#00E5FF", width=2)

        # 3. Rotating Spokes & Alignment Ribbon
        # Invert angle in canvas coordinate system (screen y points downward)
        rot_rad = math.radians(angle_deg)
        cos_a = math.cos(rot_rad)
        sin_a = math.sin(rot_rad)

        def _rot_pt(x_rel, y_rel):
            rx = x_rel * cos_a - y_rel * sin_a
            ry = x_rel * sin_a + y_rel * cos_a
            return cx + rx, cy + ry

        # Rotating top alignment stripe
        top_stripe_1 = _rot_pt(0, -inner_r)
        top_stripe_2 = _rot_pt(0, -outer_r)
        self.canvas_wheel.create_line(top_stripe_1[0], top_stripe_1[1], top_stripe_2[0], top_stripe_2[1], fill=accent_color, width=4)

        # Left spoke (9 o'clock)
        spoke_l_in = _rot_pt(-hub_r, 0)
        spoke_l_out = _rot_pt(-inner_r, 0)
        self.canvas_wheel.create_line(spoke_l_in[0], spoke_l_in[1], spoke_l_out[0], spoke_l_out[1], fill=rim_color, width=5)

        # Right spoke (3 o'clock)
        spoke_r_in = _rot_pt(hub_r, 0)
        spoke_r_out = _rot_pt(inner_r, 0)
        self.canvas_wheel.create_line(spoke_r_in[0], spoke_r_in[1], spoke_r_out[0], spoke_r_out[1], fill=rim_color, width=5)

        # Bottom spoke (6 o'clock)
        spoke_b_in = _rot_pt(0, hub_r)
        spoke_b_out = _rot_pt(0, inner_r)
        self.canvas_wheel.create_line(spoke_b_in[0], spoke_b_in[1], spoke_b_out[0], spoke_b_out[1], fill=rim_color, width=4)

        # Center Hub
        self.canvas_wheel.create_oval(cx - hub_r, cy - hub_r, cx + hub_r, cy + hub_r, fill="#121824", outline=accent_color, width=2)
        self.canvas_wheel.create_oval(cx - 4, cy - 4, cx + 4, cy + 4, fill=accent_color)

        # 4. Numerical readout
        readout_txt = f"{angle_deg:+.1f}°  |  CMD: {steering_val:+.2f}"
        self.canvas_wheel.create_text(cx, cy + outer_r + 18, text=readout_txt, fill=accent_color, font=("Consolas", 10, "bold"))

    def _draw_sim_kinematics(self):
        self.canvas_sim.delete("all")
        cx, cy = 170, 60

        # Draw radar grid
        for i in range(0, 340, 40):
            self.canvas_sim.create_line(i, 0, i, 120, fill="#0F172A", dash=(2, 4))
        for j in range(0, 120, 30):
            self.canvas_sim.create_line(0, j, 340, j, fill="#0F172A", dash=(2, 4))

        state = self.simulator.state
        heading = state.heading_rad

        # Draw robot triangle
        length = 22
        front_x = cx + length * math.cos(heading)
        front_y = cy - length * math.sin(heading)

        left_x = cx + (length / 2) * math.cos(heading + 2.5)
        left_y = cy - (length / 2) * math.sin(heading + 2.5)

        right_x = cx + (length / 2) * math.cos(heading - 2.5)
        right_y = cy - (length / 2) * math.sin(heading - 2.5)

        self.canvas_sim.create_polygon(
            front_x, front_y, left_x, left_y, right_x, right_y,
            fill="#0284C7", outline="#00E5FF", width=2
        )

        label = f"SIMULATED HEADING: {math.degrees(heading):.1f}°"
        self.canvas_sim.create_text(cx, 105, text=label, fill="#78909C", font=("Consolas", 8))

    def _main_loop(self):
        if not self._running:
            return

        # 1. Read camera frame
        has_frame, frame_data = self.camera.read_frame()
        self.safety.update_camera(has_frame)

        steering_val = 0.0
        angle_deg = 0.0
        is_tracking_locked = False

        if has_frame and frame_data is not None:
            # 2. Hand tracking (MediaPipe or OpenCV fallback)
            tracking = self.tracker.process_frame(frame_data.frame)

            # Update Left/Right status indicator tags
            l_status = "L: OK" if tracking.left_hand else "L: --"
            r_status = "R: OK" if tracking.right_hand else "R: --"
            self.lbl_hands_indicator.config(
                text=f"{l_status} | {r_status}",
                fg="#00E5FF" if tracking.both_hands_detected else "#EF5350"
            )

            # Two-hand safety gate: requires BOTH hands for valid steering
            self.safety.update_tracking(tracking.both_hands_detected)

            # 3. Calibration handling
            if self._is_calibrating:
                added = self.steering_proc.add_calibration_sample(tracking)
                elapsed = time.monotonic() - self._calib_start_time
                if elapsed >= self._calib_duration_s:
                    success = self.steering_proc.finish_calibration()
                    self._is_calibrating = False
                    if success:
                        self.btn_calib.config(text="🎯 RE-CALIBRATE", bg="#263238", fg="#00E5FF")
                        self.lbl_calib_status.config(
                            text=f"CALIBRATED (0° = {self.steering_proc.state.calibrated_neutral_deg:.1f}°)",
                            fg="#00E5FF"
                        )
                    else:
                        self.btn_calib.config(text="🎯 CALIBRATE FAILED", bg="#B71C1C", fg="#FFFFFF")
                        self.lbl_calib_status.config(text="CALIBRATION FAILED: KEEP BOTH HANDS STEADY", fg="#EF5350")

            # 4. Two-hand steering calculation
            if tracking.both_hands_detected:
                steering_val = self.steering_proc.update_two_hand(tracking)
                angle_deg = self.steering_proc.state.estimated_angle_deg - self.steering_proc.state.calibrated_neutral_deg
                if self.steering_proc.config.invert:
                    angle_deg = -angle_deg
                is_tracking_locked = True
                self.lbl_tracking_status.config(text="TWO-HAND STEERING: LOCKED", fg="#00E5FF")
            else:
                self.steering_proc.force_zero()
                if tracking.hand_detected:
                    self.lbl_tracking_status.config(text="ONE HAND DETECTED — RAISE SECOND HAND", fg="#FFB74D")
                else:
                    self.lbl_tracking_status.config(text="TRACKING LOST — EXTEND BOTH HANDS", fg="#EF5350")

            # Draw dual-hand skeleton & virtual steering chord on camera
            annotated_frame = self.tracker.draw_landmarks(frame_data.frame, tracking)

            # Convert to PhotoImage for canvas
            rgb_frame = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(rgb_frame)
            img = img.resize((520, 390))
            self._photo = ImageTk.PhotoImage(image=img)
            self.canvas_camera.delete("all")
            self.canvas_camera.create_image(0, 0, anchor="nw", image=self._photo)
        else:
            self.safety.update_tracking(False)
            self.steering_proc.force_zero()
            self.lbl_tracking_status.config(text="CAMERA OFFLINE", fg="#EF5350")
            self.lbl_hands_indicator.config(text="L: -- | R: --", fg="#78909C")

        # 5. Differential drive mixing
        drive_out = differential_drive_mix(self._target_throttle, steering_val)

        # 6. Safety Validation Gate
        v_thrott, v_steer, v_left, v_right = self.safety.validate_commands(
            self._target_throttle, steering_val, drive_out.left, drive_out.right
        )

        # 7. Simulator update
        self.simulator.update(v_left, v_right)

        # 8. Telemetry & FPS
        self.telemetry.record_camera_frame()
        self.telemetry.record_ui_frame()

        # Update HUD controls
        self._draw_virtual_wheel(v_steer, angle_deg, is_tracking_locked)
        self._draw_sim_kinematics()

        # Update Labels
        self.lbl_header_mode.config(text=f"MODE: {self.modes.mode.value}")
        state_color = {
            SafetyState.RUNNING: "#00E5FF",
            SafetyState.READY: "#64B5F6",
            SafetyState.DISARMED: "#B0BEC5",
            SafetyState.EMERGENCY_STOP: "#EF5350",
            SafetyState.TRACKING_LOST: "#FFA726",
            SafetyState.CAMERA_ERROR: "#E53935",
            SafetyState.FAULT: "#E53935",
        }.get(self.safety.state, "#FFFFFF")

        self.lbl_header_state.config(text=f"STATE: {self.safety.state.value}", fg=state_color)
        self.lbl_fps.config(text=f"FPS: {self.telemetry._camera_fps.fps:.1f}")

        self.tele_labels["lbl_steer_angle"].config(text=f"{angle_deg:+.1f}°")
        self.tele_labels["lbl_filt_steer"].config(text=f"{v_steer:+.2f}")
        self.tele_labels["lbl_left_motor"].config(text=f"{v_left:+.2f}")
        self.tele_labels["lbl_right_motor"].config(text=f"{v_right:+.2f}")
        self.tele_labels["lbl_dist"].config(text=f"{self.simulator.state.obstacle_distance_cm:.1f} cm")
        self.tele_labels["lbl_uptime"].config(text=f"{time.monotonic() - self.telemetry._app_start_time:.1f}s")

        self.root.after(33, self._main_loop)

    def _on_close(self):
        self._running = False
        self.camera.release()
        self.tracker.close()
        self.root.destroy()
