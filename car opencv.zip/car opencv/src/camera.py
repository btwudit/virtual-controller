"""
NRL JARVIS Vision — Camera Module

Acquires frames and handles camera lifecycle.
Supports Windows DirectShow backend with fallback to default.
Worker thread / Qt worker integration safe.
"""

import cv2
import time
import logging
from dataclasses import dataclass
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class CameraConfig:
    """Camera configuration parameters."""
    index: int = 0
    width: int = 640
    height: int = 480
    target_fps: int = 30
    mirror_preview: bool = True


@dataclass
class FrameData:
    """Container for captured frame data."""
    frame: any  # numpy.ndarray
    timestamp: float
    width: int
    height: int
    frame_index: int


class CameraManager:
    """
    Manages camera acquisition, reconnection, and safe resource release.
    """

    def __init__(self, config: Optional[CameraConfig] = None):
        self._config = config or CameraConfig()
        self._cap: Optional[cv2.VideoCapture] = None
        self._is_opened: bool = False
        self._frame_count: int = 0
        self._last_frame_time: Optional[float] = None
        logger.info(f"CameraManager initialized for device index {self._config.index}")

    @property
    def is_opened(self) -> bool:
        return self._is_opened and self._cap is not None and self._cap.isOpened()

    @property
    def config(self) -> CameraConfig:
        return self._config

    def open(self) -> bool:
        """
        Attempts to open webcam with CAP_DSHOW, falling back to default backend.
        """
        self.release()

        logger.info(f"Attempting to open camera {self._config.index} with CAP_DSHOW...")
        try:
            self._cap = cv2.VideoCapture(self._config.index, cv2.CAP_DSHOW)
        except Exception as e:
            logger.warning(f"DirectShow open failed: {e}")
            self._cap = None

        if self._cap is None or not self._cap.isOpened():
            logger.info("Falling back to default backend...")
            if self._cap is not None:
                self._cap.release()
            self._cap = cv2.VideoCapture(self._config.index)

        if not self._cap.isOpened():
            logger.error(f"Failed to open camera index {self._config.index}")
            self._is_opened = False
            return False

        # Set resolution and FPS
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._config.width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._config.height)
        self._cap.set(cv2.CAP_PROP_FPS, self._config.target_fps)

        self._is_opened = True
        self._frame_count = 0
        logger.info(f"Camera {self._config.index} opened successfully.")
        return True

    def read_frame(self) -> Tuple[bool, Optional[FrameData]]:
        """
        Reads a frame from the camera.
        Returns (success_flag, FrameData or None).
        """
        if not self.is_opened:
            return False, None

        ok, raw_frame = self._cap.read()
        now = time.monotonic()

        if not ok or raw_frame is None:
            logger.warning("Failed to read frame from camera.")
            return False, None

        self._frame_count += 1
        self._last_frame_time = now

        # Mirror preview if requested
        if self._config.mirror_preview:
            display_frame = cv2.flip(raw_frame, 1)
        else:
            display_frame = raw_frame

        h, w = display_frame.shape[:2]
        frame_data = FrameData(
            frame=display_frame,
            timestamp=now,
            width=w,
            height=h,
            frame_index=self._frame_count,
        )
        return True, frame_data

    def release(self) -> None:
        """Releases camera resources safely."""
        if self._cap is not None:
            try:
                self._cap.release()
            except Exception as e:
                logger.warning(f"Error releasing camera: {e}")
            self._cap = None
        self._is_opened = False
        logger.info("Camera released cleanly.")

    def reconnect(self) -> bool:
        """Reconnects to the camera."""
        logger.info("Reconnecting camera...")
        return self.open()
