import cv2

camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)

if not camera.isOpened():
    camera.release()
    camera = cv2.VideoCapture(0)

if not camera.isOpened():
    raise RuntimeError(
        "Cannot open webcam. Check camera permissions or camera index."
    )

try:
    while True:
        ok, frame = camera.read()

        if not ok:
            print("Could not read a camera frame.")
            break

        cv2.imshow("NRL Webcam Test", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
finally:
    camera.release()
    cv2.destroyAllWindows()