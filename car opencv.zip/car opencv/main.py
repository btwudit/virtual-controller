"""
NRL JARVIS Vision — Application Launcher
"""

import sys
import logging
import tkinter as tk
from src.ui.cockpit_ui import JarvisCockpitUI

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("NRL_JARVIS_VISION")


def main():
    logger.info("Starting NRL JARVIS Vision Cockpit...")
    root = tk.Tk()
    app = JarvisCockpitUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
